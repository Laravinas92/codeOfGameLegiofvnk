﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventActionsController : MonoBehaviour
{
    public delegate void EventAttackController(Soldier soldier, string letter, Vector2 direction, string typeSoldier, dataBaseAttacks dataBaseAttacks);
    public static event EventAttackController eventAttackController;

    public delegate void EventCheckMovement(string letter, Vector2 direction,List<Soldier> listSoldier);
    public static event EventCheckMovement eventCheckMovement;

    public delegate void ControllerFormation();
    public static event ControllerFormation eventControllerFormation;

    public delegate void IADestination(GameObject enemyGO, EnemyIA enemyIA);
    public static event IADestination eventIADestination;

    public static bool attackFormation = false;
    public static bool attackEnemy = false;
    public static bool objectInTheMiddle = false;
    public static bool rewardInTheMiddle = false;
    public static bool enemyOrSoldierInTheMiddle = false;
    public static bool checkEnemyIntheMiddle = false;
    public static List<Items> listObjectsToCollect = new List<Items>();
    private bool moveFormation = true;
    private GameObject FormationGO;
    public static int ChangeFormationCase;
    public static int newWidht = 0;
    public static int newHeight = 0;
    public static int tempNewWidht = 0;
    public static int tempNewHeight = 0;

    private EnemyIA enemyIA;
    private float actualDistanceToSoldier = 0;
    private Soldier actualSoldierToDistance;
    private Soldier[] randomSoldier = new Soldier[2];
    private Vector2[] possibleDirections = { new Vector2(0, 1), new Vector2(0, -1), new Vector2(1, 0), new Vector2(-1, 0) };
    public static List<Soldier> listToUpdateLive = new List<Soldier>();
    private List<Soldier> templistToUpdateLive = new List<Soldier>();
    private void OnEnable()
    {
        EventPushButtonController.eventActionsController += WhatToDoOnEventActions;
        FindEnemies.eventActionsController += WhatToDoOnEventActions;
    }
    private void OnDisable()
    {
        EventPushButtonController.eventActionsController -= WhatToDoOnEventActions;
        FindEnemies.eventActionsController -= WhatToDoOnEventActions;
    }

    private void Start()
    {
        FormationGO = GameObject.Find("Formation");
        newWidht = GameState.formationWidht;
        newHeight = GameState.formationHeight;
    }
    

    private void WhatToDoOnEventActions(string letter, Vector2 direction, string typeAction)
    {
        attackFormation = false;
        attackEnemy = false;
        moveFormation = true;


        switch (typeAction)
        {
            case "Soldier":
                
                for (int i = 0; i < Soldier.listSoldiers.Count; i++)
                {
                    if (Soldier.listSoldiers[i].Id != 0)
                    {
                        eventAttackController(Soldier.listSoldiers[i], letter, direction, "Soldier", Soldier.listSoldiers[i].TypeAttacks);
                        if (attackFormation == true)
                        {
                            moveFormation = false;
                        }
                    }
                }

                if (moveFormation == true)
                {
                    listToUpdateLive.Clear();
                    eventCheckMovement(letter, direction,Soldier.listSoldiers);
                    if (!objectInTheMiddle)
                    {
                        FormationGO.GetComponent<Formation>().UpDatePositionFormation(letter, direction, FormationGO);
                        if (rewardInTheMiddle){
                            this.gameObject.GetComponent<FindObjects>().FoundReward(listObjectsToCollect, listToUpdateLive); 
                        }
                        listToUpdateLive.Clear();
                    }
                }

                break;

            case "Enemy":

                for (int i = 0; i < Soldier.listEnemies.Count; i++)
                {
                    Vector2 directionToAttack = CheckPossibilityToAttackAndBestAttack(Soldier.listEnemies[i]);
                    if (directionToAttack == new Vector2(0, 0))//No se encuentra ningun soldado a distancia para atacarlo, entonces tenemos que buscar el mejor movimiento
                    {
                        //GameObject enemyGO = GameObject.Find("QuadEnemy_" + Soldier.listEnemies[i].Id);
                        if (Soldier.listEnemies[i].SoldierGO.GetComponent<TestEnemy>() != null)
                        {
                            if (Soldier.listEnemies[i].SoldierGO.GetComponent<TestEnemy>().NotMove == false)
                            {
                                if (Soldier.listEnemies[i].SoldierGO != null)
                                {
                                    enemyIA = Soldier.listEnemies[i].SoldierGO.GetComponent<EnemyIA>();
                                    eventIADestination(Soldier.listEnemies[i].SoldierGO, enemyIA);
                                }
                                else
                                {
                                    Debug.Log("No se encuentra al enenmigo");
                                }
                            }
                            else
                            {
                                Debug.Log("Variable NotMove testeo habilitada");
                            }

                        }
                        else
                        {
                            if (Soldier.listEnemies[i].SoldierGO != null)
                            {
                                enemyIA = Soldier.listEnemies[i].SoldierGO.GetComponent<EnemyIA>();
                                eventIADestination(Soldier.listEnemies[i].SoldierGO, enemyIA);
                            }
                            else
                            {
                                Debug.Log("No se encuentra al enenmigo");
                            }
                        }
                    }
                }
                break;

            case "Formation":

                switch (letter)
                {
                    case "f1":
                        ChangeFormationCase = 1;

                        break;

                    case "f2":
                        ChangeFormationCase = 2;
                        break;

                    case "f3":
                        ChangeFormationCase = 3;
                        break;
                }
                
                eventControllerFormation();
                checkEnemyIntheMiddle = true;
                listToUpdateLive.Clear();
                eventCheckMovement(letter, new Vector2(0, 0), Soldier.listSoldiersTemp);
                if (!objectInTheMiddle && !enemyOrSoldierInTheMiddle)
                {
                    Soldier.listSoldiers = new List<Soldier>(Soldier.listSoldiersTemp);
                    FormationGO.GetComponent<Formation>().ChangeFormation();
                    
                    if (rewardInTheMiddle)
                    {
                        this.gameObject.GetComponent<FindObjects>().FoundReward(listObjectsToCollect,listToUpdateLive);
                    }
                    listToUpdateLive.Clear();
                }
                else
                {
                    newWidht = tempNewWidht;
                    newHeight = tempNewHeight;
                    if (objectInTheMiddle){
                        Debug.Log("No se puede efectuar cambio de formación por objeto en medio ");
                    }
                    else{
                        Debug.Log("No se puede efectuar cambio de formación por enemigo en medio ");
                    }
                    
                }
                Soldier.listSoldiersTemp.Clear();
                break;
        }



        //if (typeSoldier == "Soldier")
        //{
            
        //    //else
        //    //{
        //    //    //Debug.Log("Se debe atacar, habilitar animacion o lo que sea");

        //    //}
        //}//Si lo que se chequea es un enemigo
        //else
        {
            //for (int i = 0; i < Soldier.listEnemies.Count; i++)
            //{
            //    Vector2 directionToAttack = CheckPossibilityToAttackAndBestAttack(Soldier.listEnemies[i]);
            //    if (directionToAttack == new Vector2(0, 0))//No se encuentra ningun soldado a distancia para atacarlo, entonces tenemos que buscar el mejor movimiento
            //    {
            //        //GameObject enemyGO = GameObject.Find("QuadEnemy_" + Soldier.listEnemies[i].Id);
            //        if (Soldier.listEnemies[i].SoldierGO.GetComponent<TestEnemy>()!=null)
            //        {
            //            if (Soldier.listEnemies[i].SoldierGO.GetComponent<TestEnemy>().NotMove==false)
            //            {
            //                if (Soldier.listEnemies[i].SoldierGO != null)
            //                {
            //                    enemyIA = Soldier.listEnemies[i].SoldierGO.GetComponent<EnemyIA>();
            //                    eventIADestination(Soldier.listEnemies[i].SoldierGO, enemyIA);
            //                }
            //                else
            //                {
            //                    Debug.Log("No se encuentra al enenmigo");
            //                }
            //            }
            //            else
            //            {
            //                Debug.Log("Variable NotMove testeo habilitada");
            //            }

            //        }
            //        else {
            //            if (Soldier.listEnemies[i].SoldierGO != null)
            //            {
            //                enemyIA = Soldier.listEnemies[i].SoldierGO.GetComponent<EnemyIA>();
            //                eventIADestination(Soldier.listEnemies[i].SoldierGO, enemyIA);
            //            }
            //            else
            //            {
            //                Debug.Log("No se encuentra al enenmigo");
            //            }
            //        }
                    
                    
            //    }
            //    //else
            //    //{
            //    //    Debug.Log("Se debe atacar, habilitar animacion o lo que sea");
            //    //}
            //}
        }
    }

    private Vector2 CheckPossibilityToAttackAndBestAttack(Soldier enemy)
    {
        Vector2 bestDirectionToAttackActualSoldier = new Vector2(0, 0);
        actualDistanceToSoldier = 0;
        actualSoldierToDistance = null;

        //for (int j = 0; j < Soldier.listSoldiers.Count; j++)
        //{
        //    if (Soldier.listSoldiers[j].Id !=0)
        //    {
        //bestDirectionToAttackActualSoldier = CheckAllDirectionsThatEnemyCanAttack(enemy, new Vector2(enemy.PositionX, enemy.PositionY), Soldier.listSoldiers[j], new Vector2(Soldier.listSoldiers[j].PositionX, Soldier.listSoldiers[j].PositionY));
        //    } 
        //}
        bestDirectionToAttackActualSoldier = CheckAllDirectionsThatEnemyCanAttack(enemy, new Vector2(enemy.PositionX, enemy.PositionY));

        if (bestDirectionToAttackActualSoldier != new Vector2(0, 0) && FormationGO!=null)
        {
            if (FormationGO.GetComponent<Formation>()!=null)
            {
                for (int i=0;i<listToUpdateLive.Count;i++){
                    bool var=FormationGO.GetComponent<Formation>().UpdateLifeSoldier(enemy, listToUpdateLive[i], 1, 0);
                }

                
            }
            //Quitar vidad a actualSoldierToDistance 
        }
        
        return bestDirectionToAttackActualSoldier;
    }

    public Vector2 CheckAllDirectionsThatEnemyCanAttack(Soldier enemy, Vector2 positionEnemy)
    {
        attackEnemy = false;
        Vector2 directionEnemy = new Vector2(0, 0);
        for (int i = 0; i < possibleDirections.Length; i++)
        {
            //Debug.Log("Direction a sumar:" + possibleDirections[i]);
            //Debug.Log("Position inicial del enemigo: " + positionEnemy);
            //Debug.Log("Position enemigo to Atack: " + (positionEnemy + possibleDirections[i]));
            //Debug.Log("distanceEnemySoldier otra:" + Vector2.Distance(positionEnemy - possibleDirections[i], positionSoldier));
            attackEnemy = false;
            eventAttackController(enemy, "Ninguna", possibleDirections[i], "Enemy",enemy.TypeAttacks);
            if (attackEnemy == true)
            {
                if (actualSoldierToDistance==null)
                {
                    listToUpdateLive = new List<Soldier>(dataBaseAttacks.listSoldierToUpdateLive);
                    for (int j=0;j<listToUpdateLive.Count;j++)
                    {
                        if (j == 0){
                            actualDistanceToSoldier = Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY));
                            actualSoldierToDistance = listToUpdateLive[j];
                            directionEnemy = possibleDirections[i];
                            templistToUpdateLive= new List<Soldier>(dataBaseAttacks.listSoldierToUpdateLive);
                        }
                        else
                        {
                            if (actualDistanceToSoldier >= Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY)))
                            {
                                actualSoldierToDistance = listToUpdateLive[j];
                                actualDistanceToSoldier = Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY));
                            
                            }
                        }
                        //Debug.Log("actualSDistance: " + actualDistanceToSoldier + " la otra:" + Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY)));
                        //Debug.Log("Entro1: actualSoldier:"+ actualSoldierToDistance.SoldierGO.name);
                    }
                }
                else
                {
                    listToUpdateLive = new List<Soldier>(dataBaseAttacks.listSoldierToUpdateLive);
                    for (int j = 0; j < listToUpdateLive.Count; j++)
                    {
                        
                        //Debug.Log("actualSDistance: " + actualDistanceToSoldier + " la otra:" + Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY)));
                        if (actualDistanceToSoldier >= Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY)))
                        {
                            if (actualDistanceToSoldier == Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY)))
                            {
                                //Debug.Log("Entro2: actualSoldier:" + actualSoldierToDistance.SoldierGO.name + " " + listToUpdateLive[j].SoldierGO.name);
                                if (actualSoldierToDistance.Life >= listToUpdateLive[j].Life)
                                {
                                    //Debug.Log(listToUpdateLive[j].SoldierGO.name+"Life1:" + listToUpdateLive[j].Life+"LifeOtro:"+ actualSoldierToDistance.Life+" "+ actualSoldierToDistance.SoldierGO.name);
                                    if (listToUpdateLive[j].Life == actualSoldierToDistance.Life)
                                    {
                                        if (listToUpdateLive[j].Strength >= actualSoldierToDistance.Strength)
                                        {
                                            if (listToUpdateLive[j].Strength == actualSoldierToDistance.Strength)
                                            {
                                                randomSoldier[0] = actualSoldierToDistance;
                                                randomSoldier[1] = listToUpdateLive[j];
                                                actualSoldierToDistance = randomSoldier[UnityEngine.Random.Range(0, randomSoldier.Length)];
                                                if (actualSoldierToDistance.Id == listToUpdateLive[j].Id)
                                                {
                                                    actualDistanceToSoldier = Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY));
                                                    actualSoldierToDistance = listToUpdateLive[j];
                                                    directionEnemy = possibleDirections[i];
                                                    templistToUpdateLive = new List<Soldier>(dataBaseAttacks.listSoldierToUpdateLive);
                                                }
                                            }
                                            else
                                            {
                                                actualDistanceToSoldier = Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY));
                                                directionEnemy = possibleDirections[i];
                                                actualSoldierToDistance = listToUpdateLive[j];
                                                templistToUpdateLive = new List<Soldier>(dataBaseAttacks.listSoldierToUpdateLive);
                                            }
                                        }
                                    }else
                                    {
                                        //Debug.Log("Life2:"+ listToUpdateLive[j].Life);
                                        actualDistanceToSoldier = Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY));
                                        directionEnemy = possibleDirections[i];
                                        actualSoldierToDistance = listToUpdateLive[j];
                                        templistToUpdateLive = new List<Soldier>(dataBaseAttacks.listSoldierToUpdateLive);
                                    }
                                }
                            }
                            else
                            {
                                actualDistanceToSoldier = Vector2.Distance(positionEnemy, new Vector2(listToUpdateLive[j].PositionX, listToUpdateLive[j].PositionY));
                                directionEnemy = possibleDirections[i];
                                actualSoldierToDistance = listToUpdateLive[j];
                                templistToUpdateLive = new List<Soldier>(dataBaseAttacks.listSoldierToUpdateLive);
                            }
                        }
                    }
                    //Debug.Log("Entro3: actualSoldier:" + actualSoldierToDistance.SoldierGO.name);
                }
            }
        }
        listToUpdateLive = new List<Soldier>(templistToUpdateLive);
        //Debug.Log("Direccion Ataque enemigo:" +directionEnemy);
        return directionEnemy;
    }
}
