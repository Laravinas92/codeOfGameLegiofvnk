﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
#if UNITY_EDITOR
using UnityEditor;
#endif
[ExecuteInEditMode]
public class SelecTypeEnemy : MonoBehaviour
{
    private GameObject SO_ManagerGO;
    private void OnEnable()
    {
        SO_ManagerGO = GameObject.FindGameObjectWithTag("SO");
        tempEnemyType = EnemyType.ToString();

    }
    public enum typeEnemy
    {
        Legionario,
        LegionarioMejorado,
        Arquero,
        Cazador,
        Hondero,
        Lancero,
        Gladiador,
        Pretoriano,
        Medico,
        Sacerdote,
        Barbaro
    }

    public typeEnemy EnemyType;
    private string tempEnemyType;

    private void Update()
    {
        if (tempEnemyType != EnemyType.ToString() && gameObject.layer == 9)
        {
            dataBaseSoldiers soldierDB=SO_ManagerGO.GetComponent<SO_Manager>().UpdateMaterialSoldier(this.gameObject,EnemyType.ToString(), 1);
            tempEnemyType = EnemyType.ToString();
        }
    }
}

    