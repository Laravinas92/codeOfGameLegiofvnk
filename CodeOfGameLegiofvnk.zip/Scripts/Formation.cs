﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

[ExecuteInEditMode]
public class Formation: MonoBehaviour 
{
    private GameObject soldierGO;
    private int rows;
    private int columns;
    private float InfinityLife = 100000;


#if UNITY_EDITOR

    private void OnEnable()
    {
        if (this.gameObject.GetComponent<TestFormation>()==null && !Application.isPlaying)
        {
            this.gameObject.AddComponent<TestFormation>();
            
        }
    }
#endif

    private void Awake()
    {
        rows = 0;
        columns = 0;
    }
    
    public void createSoldier(DataBaseFormation formationDB,dataBaseSoldiers soldierDB,Transform transformFormation)
    {
        //if (Soldier.listSoldiers.Count==0)
        //{
        //    refFormationToRotate = GameObject.CreatePrimitive(PrimitiveType.Cube);
        //    refFormationToRotate.name = "refFormationToRotate";
        //    refFormationToRotate.GetComponent<MeshRenderer>().enabled = false;
        //    refFormationToRotate.GetComponent<Collider>().enabled = false;
        //    refFormationToRotate.transform.localScale = new Vector3(formationDB.width,formationDB.height,0.99f);
        //    refFormationToRotate.transform.position = new Vector3(transform.position.x-0.5f + formationDB.width/2f, (transform.position.y+0.5f - formationDB.height/2f),0.99f);
        //    refFormationToRotate.transform.SetParent(this.transform);
        //}

        if (Soldier.listSoldiers.Count < formationDB.height*formationDB.width)
        {
            AddSoldier(formationDB,soldierDB, transformFormation);
        }

        if (Soldier.listSoldiers.Count == (formationDB.height * formationDB.width))
        {
            ToAssignId();
        }
    }

    private void AddSoldier(DataBaseFormation formationDB,dataBaseSoldiers soldierDB, Transform transformFormation)
    {
        float life;
        soldierGO = Instantiate(soldierDB.iconUnit, new Vector3(transformFormation.position.x + columns, transformFormation.position.y - rows, 0.99f), Quaternion.identity);
        
        if (soldierGO != null)
        {
            soldierGO.GetComponent<MeshRenderer>().material = soldierDB.materialUnit;
            soldierGO.transform.SetParent(transformFormation);
            //soldierGO.transform.SetParent(transformFormation.GetChild(0).transform);
            if (soldierGO.GetComponent<TesteoSoldier>()==null)
            {
                soldierGO.AddComponent<TesteoSoldier>();
            }
            soldierGO.name = "soldier_" + (Soldier.listSoldiers.Count + 1);
            GetComponent<ModifyIconLife>().PutSpriteLife(soldierDB.life, soldierGO);

            if (this.gameObject.GetComponent<TestFormation>()!=null)
            {
                if (this.gameObject.GetComponent<TestFormation>().ModoDios==true)
                {
                    
                    if (soldierGO.GetComponent<TesteoSoldier>() != null)
                    {
                        soldierGO.GetComponent<TesteoSoldier>().SoldierDied = false;
                        life = InfinityLife;
                        soldierGO.GetComponent<TesteoSoldier>().life = InfinityLife;
                    }
                    else
                    {
                        life = InfinityLife;
                    }
                }
                else
                {
                    if (soldierGO.GetComponent<TesteoSoldier>() != null)
                    {
                        if (soldierGO.GetComponent<TesteoSoldier>().SoldierDied == true)
                        {
                            life = 0;
                            soldierGO.GetComponent<TesteoSoldier>().life = 0;
                        }
                        else
                        {
                            life = soldierDB.life;
                            soldierGO.GetComponent<TesteoSoldier>().life = soldierDB.life;
                        }
                    }
                    else
                    {
                        life = soldierDB.life;
                    }
                }
            }
            else
            {
                life = soldierDB.life;
            }
            //Debug.Log(life +" "+ soldierDB.life+" "+ soldierGO.GetComponent<TesteoSoldier>().life);
            soldierGO.GetComponent<Transform>().position = new Vector3(transformFormation.position.x + columns, transformFormation.position.y - rows, 0.99f);
            Soldier.listSoldiers.Add(new Soldier(life,soldierDB.life, soldierDB.typeSoldier, soldierDB.strength, soldierDB.typeAttacks, soldierDB.specialAbility, soldierDB.iconUnit, transformFormation.position.x + columns, transformFormation.position.y - rows, 1, soldierGO,soldierDB.materialUnit));
            //soldierSC.AddSoldierToList(soldierDB, new Vector3(transformSoldierParent.position.x + columns, transformSoldierParent.position.y - rows, 00f), "soldier");
            //listPositionsFormation.Add(new Vector2(transformFormation.position.x + columns, transformFormation.position.y - rows));
        }
        else
        {
            Debug.Log("No se encuentra el objeto de nombre" + soldierGO.name);
        }

        columns++;
        if (columns > (formationDB.width-1))
        {
            columns = 0;
            rows++;
        }    
    }

    private void ToAssignId()
    {
        int ids = 1;
        for (int i = 0; i < Soldier.listSoldiers.Count; i++)
        {
            if (Soldier.listSoldiers[i].Life != 0)
            {
                Soldier.listSoldiers[i].Id = ids;
            }
            else
            {
                Soldier.listSoldiers[i].Id = 0;
            }
            
            ids++;
            //Debug.Log(Soldier.listSoldiers[i].Id);
            //Debug.Log(Soldier.listSoldiers[i].Life);
        }
    }

    public void UpDatePositionFormation(string letter,Vector2 direction,GameObject formationGO)
    {
        if (letter == "w")
        {
            formationGO.GetComponent<Transform>().position = new Vector3(formationGO.GetComponent<Transform>().position.x, formationGO.GetComponent<Transform>().position.y+1,0.99f);

        }
        else
        {
            if (letter == "s")
            {
                formationGO.GetComponent<Transform>().position = new Vector3(formationGO.GetComponent<Transform>().position.x, formationGO.GetComponent<Transform>().position.y - 1, 0.99f);
            }
            else
            {
                if (letter == "a")
                {
                    formationGO.GetComponent<Transform>().position = new Vector3(formationGO.GetComponent<Transform>().position.x-1, formationGO.GetComponent<Transform>().position.y, 0.99f);
                }

                else
                {
                    if (letter == "d")
                    {
                        formationGO.GetComponent<Transform>().position = new Vector3(formationGO.GetComponent<Transform>().position.x + 1, formationGO.GetComponent<Transform>().position.y, 0.99f);
                    }

                }
            }

        }

        for (int i = 0; i < Soldier.listSoldiers.Count; i++)
        {
            //Debug.Log("X" + direction.x + "Y" + direction.y);
            Soldier.listSoldiers[i].PositionX=(Soldier.listSoldiers[i].PositionX - direction.x);
            Soldier.listSoldiers[i].PositionY=(Soldier.listSoldiers[i].PositionY - direction.y);
            //Debug.Log("Posicion Actualizada Soldado X" + Soldier.listSoldiers[i].PositionX + "Y" + Soldier.listSoldiers[i].PositionY);
            
        }
    }

    public void ChangeFormation()
    {
        for (int i=0;i<Soldier.listSoldiers.Count;i++){
            Soldier.listSoldiers[i].SoldierGO.GetComponent<Transform>().position = new Vector3(Soldier.listSoldiers[i].PositionX, Soldier.listSoldiers[i].PositionY, 0.99f);
        }

    }

    public bool UpdateLifeSoldier(Soldier enemy,Soldier soldierToUpdate,int caseNumber,float lifeExtra)//1DOWN,2UP
    {
        switch (caseNumber)
        {
            case 1:

                for (int j = 0; j < Soldier.listSoldiers.Count; j++)
                {
                    if (Soldier.listSoldiers[j].Id != 0)
                    {
                        if (Soldier.listSoldiers[j].SoldierGO.name == soldierToUpdate.SoldierGO.name)
                        {
                            Soldier.listSoldiers[j].Life -= enemy.Strength;

                            if (Soldier.listSoldiers[j].Life <= 0)
                            {
                                Soldier.listSoldiers[j].Life = 0;
                                GetComponent<ModifyIconLife>().DesactiveIconLife(Soldier.listSoldiers[j].Life, Soldier.listSoldiers[j].SoldierGO);
                                RemoveSoldierOfTheList(Soldier.listSoldiers[j]);
                            }
                            else
                            {
                                GetComponent<ModifyIconLife>().DesactiveIconLife(Soldier.listSoldiers[j].Life, Soldier.listSoldiers[j].SoldierGO);
                            }
                            if (soldierToUpdate.SoldierGO.GetComponent<TesteoSoldier>() != null)
                            {
                                soldierToUpdate.SoldierGO.GetComponent<TesteoSoldier>().life = Soldier.listSoldiers[j].Life;
                            }
                            break;
                        }
                    }
                }
                return false;

            case 2:
                if (soldierToUpdate.Life < soldierToUpdate.LifeDB)
                {
                    soldierToUpdate.Life += lifeExtra;
                    if (soldierToUpdate.SoldierGO.GetComponent<TesteoSoldier>() != null)
                    {
                        if (soldierToUpdate.Life >= soldierToUpdate.LifeDB)
                        {
                            soldierToUpdate.Life = soldierToUpdate.LifeDB;
                        }
                        soldierToUpdate.SoldierGO.GetComponent<TesteoSoldier>().life = soldierToUpdate.Life;
                    }
                    else
                    {
                        if (soldierToUpdate.Life >= soldierToUpdate.LifeDB)
                        {
                            soldierToUpdate.Life = soldierToUpdate.LifeDB;
                        }
                    }
                    //Debug.Log(soldierToUpdate.SoldierGO);
                    GetComponent<ModifyIconLife>().ActiveIconLife(soldierToUpdate.Life, soldierToUpdate.SoldierGO);
                    return true;
                }
                else
                {
                    return false;
                }
            default:
                return false;

        }
        //soldier.Life += lifeExtra;

        //GetComponent<ModifyIconLife>().AddIconLife((int)lifeExtra, soldier.SoldierGO);
        //if (soldier.Life > soldier.LifeDB)
        //{
        //    if (soldier.SoldierGO.GetComponent<TesteoSoldier>() != null)
        //    {
        //        soldier.Life += lifeExtra;
        //        soldier.SoldierGO.GetComponent<TesteoSoldier>().life = soldier.Life;
        //    }
        //    else
        //    {
        //        soldier.Life = soldier.LifeDB;
        //    }
        //}


        //if (Soldier.listSoldiers[j].Id != 0)
        //{
        //    Soldier.listSoldiers[j].Life += lifeExtra;
        //    GetComponent<ModifyIconLife>().AddIconLife((int)lifeExtra, Soldier.listSoldiers[j].SoldierGO);
        //    if (Soldier.listSoldiers[j].Life > Soldier.listSoldiers[j].LifeDB)
        //    {
        //        if (Soldier.listSoldiers[j].SoldierGO.GetComponent<TesteoSoldier>() != null)
        //        {
        //            Soldier.listSoldiers[j].Life += lifeExtra;
        //            Soldier.listSoldiers[j].SoldierGO.GetComponent<TesteoSoldier>().life = Soldier.listSoldiers[j].Life;
        //        }
        //        else
        //        {
        //            Soldier.listSoldiers[j].Life = Soldier.listSoldiers[j].LifeDB;
        //        }
        //    }
        //}
        //if (Soldier.listSoldiers[j].SoldierGO.GetComponent<TesteoSoldier>() != null)
        //{

        //    Soldier.listSoldiers[j].SoldierGO.GetComponent<TesteoSoldier>().life = Soldier.listSoldiers[j].Life;
        //}





    }

    private void RemoveSoldierOfTheList(Soldier soldier)
    {
        soldier.Id = 0;
        soldier.SoldierGO.SetActive(false);
    }
}
