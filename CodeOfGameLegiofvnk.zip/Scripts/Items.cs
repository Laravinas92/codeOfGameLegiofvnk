﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Items
{
    public string NameItem { get; set; }
    public float Affectation { get; set; }
    public bool PieceSoldier{ get; set; }
    public GameObject RewardGO { get; set; }


    public Items() { }

    public Items(string nameItem,float affectation,bool pieceSoldier, GameObject rewardGO)
    {
        NameItem = nameItem;
        Affectation = affectation;
        PieceSoldier = pieceSoldier;
        RewardGO = rewardGO;
    }
}
