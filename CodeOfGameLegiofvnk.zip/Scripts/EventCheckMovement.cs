﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventCheckMovement : MonoBehaviour
{
    //private GameObject FormationGO;//formacion en un futuro
    //private FindObjects findObjectsSC;
    

    private void OnEnable()
    {
        EventActionsController.eventCheckMovement += CheckPositionObjects;
        EventActionsController.eventCheckMovement += CheckPositionEnemysOrSoldiers;
       
        
    }

    private void OnDisable()
    {
        EventActionsController.eventCheckMovement -= CheckPositionObjects;
        EventActionsController.eventCheckMovement -= CheckPositionEnemysOrSoldiers;
    }

    private void Start()
    {
        //formationSC = FindObjectOfType<Formation>();
        //FormationGO = GameObject.Find("Formation");
        //findObjectsSC = FindObjectOfType<FindObjects>();



    }


    private void CheckPositionEnemysOrSoldiers(String letter,Vector2 direction,List<Soldier> listSoldiers)
    {
        EventActionsController.enemyOrSoldierInTheMiddle = false;
        if (!EventActionsController.objectInTheMiddle && EventActionsController.checkEnemyIntheMiddle)
        {
            for (int i = 0; i < listSoldiers.Count; i++)
            {
                for (int j = 0; j < Soldier.listEnemies.Count; j++)
                {

                    if (letter == "f")
                    {
                        if (listSoldiers[i].PositionX == Soldier.listEnemies[j].PositionX && listSoldiers[i].PositionY == Soldier.listEnemies[j].PositionY)
                        {
                            EventActionsController.enemyOrSoldierInTheMiddle = true;
                            break;
                        }
                    }
                    else
                    {
                        //Debug.Log("Posicion Soldado X"+ (listSoldiers[j].getPositionX()-direction.x) + "Y"+ (listSoldiers[j].getPositionY()-direction.y));
                        //Debug.Log("Posicion Enemigo X" + Soldier.listEnemies[i].getPositionX() + "Y" + Soldier.listEnemies[i].getPositionY());
                        if ((listSoldiers[i].PositionX - direction.x) == Soldier.listEnemies[j].PositionX && (listSoldiers[i].PositionY - direction.y) == Soldier.listEnemies[j].PositionY)
                        {
                            EventActionsController.enemyOrSoldierInTheMiddle = true;
                            break;
                        }

                    }

                }
                if (EventActionsController.enemyOrSoldierInTheMiddle == true)
                {
                    break;
                }
            }
        }
        EventActionsController.checkEnemyIntheMiddle = false;
    }


    private void CheckPositionObjects(String letter,Vector2 direction, List<Soldier> listSoldiers)
    {
        EventActionsController.objectInTheMiddle = false;
        EventActionsController.rewardInTheMiddle = false;
        for (int i = 0; i < FindObjects.listIntransitables.Count; i++)
        {
            for (int j = 0; j < listSoldiers.Count; j++)
            {
                if (listSoldiers[j].Id != 0)
                {
                    if (letter=="f")
                    {

                        if (listSoldiers[j].PositionX == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x &&
                            listSoldiers[j].PositionY == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y)
                        {
                            EventActionsController.objectInTheMiddle = true;
                            //Debug.Log("No te puedes mover OBJETO en medio");
                            break;
                        }
                    }
                    else
                    {
                        //Debug.Log("Posicion Soldado X" + (listSoldiers[j].getPositionX() - direction.x) + "Y" + (listSoldiers[j].getPositionY() - direction.y));
                        //Debug.Log("Posicion Enemigo X" + Soldier.listEnemies[i].getPositionX() + "Y" + Soldier.listEnemies[i].getPositionY());
                        if (((listSoldiers[j].PositionX - direction.x) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x) &&
                        ((listSoldiers[j].PositionY - direction.y) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y))
                        {
                            EventActionsController.objectInTheMiddle = true;
                            //Debug.Log("No te puedes mover OBJETO en medio");
                            break;
                        }
                    }
                    
                }
            }
            if (EventActionsController.objectInTheMiddle == true)
            {
                break;
            }
        }

        if (EventActionsController.objectInTheMiddle ==false) //&& FormationGO!=null
        {
            EventActionsController.listObjectsToCollect.Clear();
            for (int i=0;i<FindObjects.listReward.Count;i++)
            {
                for (int j = 0; j < listSoldiers.Count; j++)
                {
                    if (listSoldiers[j].Id != 0)
                    {
                        if (letter=="f")
                        {
                            if (listSoldiers[j].PositionX == FindObjects.listReward[i].RewardGO.GetComponent<Transform>().position.x &&
                                listSoldiers[j].PositionY - direction.y == FindObjects.listReward[i].RewardGO.GetComponent<Transform>().position.y)
                            {
                                EventActionsController.listObjectsToCollect.Add(FindObjects.listReward[i]);
                                EventActionsController.listToUpdateLive.Add(listSoldiers[j]);
                                EventActionsController.rewardInTheMiddle = true;
                            }
                        }
                        else
                        {
                            //Debug.Log("Posicion Soldado X" + (listSoldiers[j].getPositionX() - direction.x) + "Y" + (listSoldiers[j].getPositionY() - direction.y));
                            //Debug.Log("Posicion Enemigo X" + Soldier.listEnemies[i].getPositionX() + "Y" + Soldier.listEnemies[i].getPositionY());
                            if (((listSoldiers[j].PositionX - direction.x) == FindObjects.listReward[i].RewardGO.GetComponent<Transform>().position.x) &&
                                                        ((listSoldiers[j].PositionY - direction.y) == FindObjects.listReward[i].RewardGO.GetComponent<Transform>().position.y))
                            {
                                EventActionsController.listObjectsToCollect.Add(FindObjects.listReward[i]);
                                EventActionsController.listToUpdateLive.Add(listSoldiers[j]);
                                EventActionsController.rewardInTheMiddle = true;

                            }
                        }
                        
                        
                    }
                }
            }

            //FormationGO.GetComponent<Formation>().UpDatePositionFormation(letter, direction,FormationGO);
            //if (EventActionsController.rewardInTheMiddle == true)
            //{
            //    findObjectsSC.FoundReward(listObjectsToCollect);

            //}
        }
    }

    
}
