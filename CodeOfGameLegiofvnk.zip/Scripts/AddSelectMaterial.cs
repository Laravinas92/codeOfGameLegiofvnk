﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;

[ExecuteInEditMode]
public class AddSelectMaterial : MonoBehaviour
{
    private GameObject EnemiesGO;

    private void OnEnable()
    {
        EnemiesGO = GameObject.Find("Enemies");
        if (gameObject.layer == 9 && !Application.isPlaying && gameObject.GetComponent<SelectMaterial>() == null && gameObject.GetComponent<SelecTypeEnemy>() == null)
        {
            gameObject.transform.SetParent(EnemiesGO.transform);
            gameObject.AddComponent<SelectMaterial>();
            gameObject.AddComponent<SelecTypeEnemy>();
        }

    }
}
#endif