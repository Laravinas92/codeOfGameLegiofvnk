﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindEnemies : MonoBehaviour
{
    public delegate void EventActionsController(string letter, Vector2 direction, string typeSoldier);
    public static event EventActionsController eventActionsController;
    private dataBaseSoldiers soldierDB;
    private Vector3 gridSize = new Vector3(1, 1, 0.99f);
    private TestEnemy TestEnemyGO;
    private float InfinityLife = 100000;
    private List<Soldier> tempListSoldierEnemy = new List<Soldier>();
    private GameObject[] enemiesGO;
    private SO_Manager SO_ManagerSC;


    // Start is called before the first frame update
    void Start()
    {
        SO_ManagerSC = FindObjectOfType<SO_Manager>();
        int ids = 1;
        float life = 0;
        enemiesGO= GameObject.FindGameObjectsWithTag("Enemy");

        for (int i = 0; i < enemiesGO.Length; i++)
        {
            soldierDB= SO_ManagerSC.UpdateMaterialSoldier(enemiesGO[i],enemiesGO[i].GetComponent<SelecTypeEnemy>().EnemyType.ToString(),2);
            enemiesGO[i].gameObject.name = "QuadEnemy_" + ids;
            
            GetComponent<ModifyIconLife>().PutSpriteLife(soldierDB.life, enemiesGO[i]);
                
           

#if UNITY_EDITOR
            enemiesGO[i].GetComponent<SnapGrid>().enabled = false;
#endif
            TestEnemyGO = enemiesGO[i].GetComponent<TestEnemy>();
            if (TestEnemyGO != null)
            {
                if (TestEnemyGO.ModoDios == true)
                {
                    TestEnemyGO.life = InfinityLife;
                    life = InfinityLife;
                }
                else
                {
                    TestEnemyGO.life = soldierDB.life;
                    life = soldierDB.life;
                }
            }
            else
            {
                TestEnemyGO.life = soldierDB.life;
                life = soldierDB.life;
            }
            Soldier.listEnemies.Add(new Soldier(life, soldierDB.life, soldierDB.typeSoldier, soldierDB.strength, soldierDB.typeAttacks, soldierDB.specialAbility, soldierDB.iconEnemy, enemiesGO[i].transform.position.x, enemiesGO[i].transform.position.y, ids, enemiesGO[i].gameObject,soldierDB.materialEnemy));
            ids++;

        }
    }

    

    private void Update()
    {
        if (ManagerBeat.impar == true)
        {
            //WhatToDoOnEventActions("nada", new Vector2(-5,-5), "Enemy");
            eventActionsController("nada", new Vector2(-5, -5), "Enemy");
            ManagerBeat.impar = false;
        }
    }

    public void UpdatePostitionEnemy(GameObject enemyGO, Vector3 position)
    {
        string[] str = enemyGO.name.Split(char.Parse("_"));
        int aux_id = Int32.Parse(str[1]);
        for (int i = 0; i < Soldier.listEnemies.Count; i++)
        {
            if (aux_id == Soldier.listEnemies[i].Id)
            {
                //enemyGO.GetComponent<Collider2D>().enabled = false;
                // AstarPath.active.UpdateGraphs(enemyGO.GetComponent<Collider2D>().bounds);
                enemyGO.transform.position = SnapToGrid(position);
                //enemyGO.GetComponent<Collider2D>().enabled = true;
                //AstarPath.active.UpdateGraphs(enemyGO.GetComponent<Collider2D>().bounds);
                Soldier.listEnemies[i].PositionX = enemyGO.transform.position.x;
                Soldier.listEnemies[i].PositionY = enemyGO.transform.position.y;
                //Debug.Log("Posicion Enemigo Actualizada PositionX: "+ Soldier.listEnemies[i].PositionX+ "PositionY: " + Soldier.listEnemies[i].PositionY);


            }

        }
    }
    private Vector3 SnapToGrid(Vector3 vectorSnap)
    {
        Vector3 position = new Vector3(
            Mathf.RoundToInt(vectorSnap.x / this.gridSize.x) * this.gridSize.x,
            Mathf.RoundToInt(vectorSnap.y / this.gridSize.y) * this.gridSize.y,
            gridSize.z
            );
        return position;
    }

    public void UpdateLifeEnemy(float damage)
    {
        bool died;
        for (int j = 0; j < Soldier.listEnemies.Count; j++)
        {
            died = false;
            for (int i=0;i< dataBaseAttacks.listSoldierToUpdateLive.Count;i++)
            {
                if (Soldier.listEnemies[j].SoldierGO.name == dataBaseAttacks.listSoldierToUpdateLive[i].SoldierGO.name)
                {
                    Soldier.listEnemies[j].Life -=  damage;
                    if (Soldier.listEnemies[j].Life <= 0)
                    {
                        died = true;
                        Soldier.listEnemies[j].Life = 0;
                        GetComponent<ModifyIconLife>().DesactiveIconLife(Soldier.listEnemies[j].Life, Soldier.listEnemies[j].SoldierGO);
                        RemoveEnemyOfTheList(Soldier.listEnemies[j]);
                    }
                    else
                    {
                        GetComponent<ModifyIconLife>().DesactiveIconLife(Soldier.listEnemies[j].Life, Soldier.listEnemies[j].SoldierGO);
                    }
                    if (dataBaseAttacks.listSoldierToUpdateLive[i].SoldierGO.GetComponent<TestEnemy>() != null)
                    {
                        dataBaseAttacks.listSoldierToUpdateLive[i].SoldierGO.GetComponent<TestEnemy>().life = Soldier.listEnemies[j].Life;
                    }
                    break;
                }
            }
            if (died==false)
            {
                tempListSoldierEnemy.Add(Soldier.listEnemies[j]);
            }
        }
        Soldier.listEnemies = new List<Soldier>(tempListSoldierEnemy);
        tempListSoldierEnemy.Clear();
    }

    private void RemoveEnemyOfTheList(Soldier soldier)
    {
        //soldier.SoldierGO.SetActive(false);

        if (soldier.SoldierGO.GetComponent<SelectMaterial>().GiveReward == true)
        {
            SO_ManagerSC.UpdateMaterialPiece(soldier.SoldierGO,soldier.SoldierGO.GetComponent<SelectMaterial>().rewardPiece.ToString());
            soldier.SoldierGO.name = soldier.SoldierGO.GetComponent<SelectMaterial>().rewardPiece.ToString();
            soldier.SoldierGO.transform.SetParent(null);
            soldier.SoldierGO.name = soldier.SoldierGO.GetComponent<SelectMaterial>().rewardPiece.ToString();
            SO_ManagerSC.AddItemToList(soldier.SoldierGO,true);
            soldier.SoldierGO.GetComponent<SelectMaterial>().GiveReward = false;
        }
        else
        {
            soldier.SoldierGO.transform.SetParent(null);
            soldier.SoldierGO.SetActive(false);
            //soldier.SoldierGO.GetComponent<SelectMaterial>().UpdateMaterial(soldier.SoldierGO.GetComponent<SelectMaterial>().transitablePiece.ToString());
            //soldier.SoldierGO.name = soldier.SoldierGO.GetComponent<SelectMaterial>().transitablePiece.ToString();
        }
        
    }
}
