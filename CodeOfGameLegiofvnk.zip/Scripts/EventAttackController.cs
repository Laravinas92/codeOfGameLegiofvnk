﻿using System;
using UnityEngine;

public class EventAttackController : MonoBehaviour
{
    private int contAttackSoldier = 0;
    private bool attackBody = false;
    private bool attackDistance = false;
    private bool attackEstocada = false;
    private bool attackBarrido = false;
    private FindEnemies findEnemiesSC;
    private FindObjects findObjectsSC;

    private void Start()
    {
        findEnemiesSC= FindObjectOfType<FindEnemies>();
        findObjectsSC= FindObjectOfType<FindObjects>();
    }
    private void OnEnable()
    {
        EventActionsController.eventAttackController += CheckPossibilityOfAttack;
    }

    private void OnDisable()
    {
        EventActionsController.eventAttackController -= CheckPossibilityOfAttack;
    }

    private void CheckPossibilityOfAttack(Soldier soldier,String letter, Vector2 direction, string typeSoldier, dataBaseAttacks attackDBSelected)
    {
        int minDistanceAtt;
        int maxDistanceAtt;
        attackBody = false;
        attackDistance = false;
        attackEstocada = false;
        attackBarrido = false;
        
        switch (attackDBSelected.name)
        {
            case "Cuerpo":
                maxDistanceAtt = attackDBSelected.maxDistanceAtack;
                attackBody = attackDBSelected.CheckAttackCuerpoACuerpo(soldier.PositionX, soldier.PositionY, direction, maxDistanceAtt,typeSoldier);
                
                if (attackBody==true && typeSoldier == "Soldier")
                {
                    if (dataBaseAttacks.listSoldierToUpdateLive.Count!=0)
                    {
                        findEnemiesSC.UpdateLifeEnemy(soldier.Strength);
                    }
                    if (dataBaseAttacks.listObjectToUpdateLive.Count!=0)
                    {

                        findObjectsSC.UdateLifeObject(soldier.Strength);
                    }
                    
                    contAttackSoldier++;
                }
                else
                {
                    if (attackBody == true && typeSoldier == "Enemy")
                    {
                        contAttackSoldier++;
                    }
                }
                break;

            case "Distancia":

                minDistanceAtt = attackDBSelected.minDistanceAtack;
                maxDistanceAtt = attackDBSelected.maxDistanceAtack;
                
                attackDistance = attackDBSelected.CheckAttackDistance(soldier.PositionX, soldier.PositionY, direction, minDistanceAtt, maxDistanceAtt, typeSoldier);
                if (attackDistance == true && typeSoldier == "Soldier")
                {
                    if (dataBaseAttacks.listSoldierToUpdateLive.Count != 0)
                    {
                        findEnemiesSC.UpdateLifeEnemy(soldier.Strength);
                    }
                    if (dataBaseAttacks.listObjectToUpdateLive.Count != 0)
                    {

                        findObjectsSC.UdateLifeObject(soldier.Strength);
                    }
                    contAttackSoldier++;
                }
                else
                {
                    if (attackDistance == true && typeSoldier == "Enemy")
                    {
                        contAttackSoldier++;
                    }
                }
                break;

            case "Estocada":
                
                minDistanceAtt = attackDBSelected.minDistanceAtack;
                maxDistanceAtt = attackDBSelected.maxDistanceAtack;
                attackEstocada = attackDBSelected.CheckAttackEstocada(soldier.PositionX, soldier.PositionY, direction, minDistanceAtt, maxDistanceAtt, typeSoldier);
                if (attackEstocada == true && typeSoldier == "Soldier")
                {
                    if (dataBaseAttacks.listSoldierToUpdateLive.Count != 0)
                    {
                        findEnemiesSC.UpdateLifeEnemy(soldier.Strength);
                    }
                    if (dataBaseAttacks.listObjectToUpdateLive.Count != 0)
                    {

                        findObjectsSC.UdateLifeObject(soldier.Strength);
                    }
                    contAttackSoldier++;
                }
                else
                {
                    if (attackEstocada == true && typeSoldier == "Enemy")
                    {
                        contAttackSoldier++;
                    }
                }
                break;

            case "Barrido":
                
                minDistanceAtt = attackDBSelected.minDistanceAtack;
                maxDistanceAtt = attackDBSelected.maxDistanceAtack;
                attackBarrido = attackDBSelected.CheckAttackBarrido(soldier.PositionX, soldier.PositionY, direction, minDistanceAtt, maxDistanceAtt, typeSoldier);
                if (attackBarrido == true && typeSoldier == "Soldier")
                {
                    if (dataBaseAttacks.listSoldierToUpdateLive.Count != 0)
                    {
                        findEnemiesSC.UpdateLifeEnemy(soldier.Strength);
                    }
                    if (dataBaseAttacks.listObjectToUpdateLive.Count != 0)
                    {

                        findObjectsSC.UdateLifeObject(soldier.Strength);
                    }
                    contAttackSoldier++;
                }
                else
                {
                    if (attackBarrido == true && typeSoldier == "Enemy")
                    {
                        contAttackSoldier++;
                    }
                }
                break;
        }

        if (contAttackSoldier != 0 && typeSoldier == "Soldier")
        {
            EventActionsController.attackFormation = true;
            contAttackSoldier = 0;
        }
        else
        {
            if (contAttackSoldier != 0 && typeSoldier == "Enemy")
            {
                EventActionsController.attackEnemy = true;
                contAttackSoldier = 0;
            }
        }
    }
 }




