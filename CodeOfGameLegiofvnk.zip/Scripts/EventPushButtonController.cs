﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventPushButtonController : MonoBehaviour
{
   // private float timePreviousButtonPress=0;
    private float timePreviousPulse = 0;
    private bool flag_1 = true;
    private bool flag_2 = true;
    private bool enter = false;
    //private AttackEnemy attackEnemySC;

    public delegate void EventActionsController(string letter,Vector2 direction,string typeSoldier);
    public static event EventActionsController eventActionsController;

    private void Start()
    {
        //attackEnemySC = FindObjectOfType<AttackEnemy>();
    }
    private void OnEnable()
    {
       EventPushButton.eventPushBotton += WhatToDoOnPushBotton;
    }

    private void OnDisable()
    {
        EventPushButton.eventPushBotton -= WhatToDoOnPushBotton;
    }

    private void WhatToDoOnPushBotton(string letter,Vector2 direction ,float timePushBotton)
    {

        //Debug.Log("Pulso previo"+timePreviousPulse);
        //Debug.Log("Pulso Actual"+ManagerBeat.timePulse);
        //Debug.Log("Boton pulsado: " + timePushBotton);
        //Debug.Log("Pulso: " + ManagerBeat.timePulse + "Limite1: " + (ManagerBeat.timePulse + ManagerBeat.upperLimitPulse) + "Limite2: " + (ManagerBeat.timePulse + ManagerBeat.pulse - ManagerBeat.lowerLimitPulse) + "Fin: " + (ManagerBeat.timePulse + ManagerBeat.pulse));
        
        enter = false;
        if ((flag_1==true &&  timePushBotton> timePreviousPulse+ManagerBeat.upperLimitPulse) || (flag_2==true && timePushBotton> timePreviousPulse+ManagerBeat.pulse+ ManagerBeat.upperLimitPulse))
        {
            enter=true;
        }
        //Debug.Log("Entro" + enter);
        if (enter==true)
        {
            
            if (((timePushBotton >= ManagerBeat.timePulse) && (timePushBotton <= (ManagerBeat.timePulse + ManagerBeat.upperLimitPulse))) || ((timePushBotton >= (ManagerBeat.timePulse + ManagerBeat.pulse - ManagerBeat.lowerLimitPulse)) && (timePushBotton <= (ManagerBeat.timePulse + ManagerBeat.pulse))))
            {
                //Debug.Log("A Ritmo");
                if (letter=="f1" || letter == "f2" || letter == "f3")
                {
                    eventActionsController(letter, direction, "Formation");
                }
                else
                {
                    eventActionsController(letter, direction, "Soldier");
                }
                
                //if (letter == "w")
                //{

                //    //Debug.Log("Tecla W pulsada:"+ timePushBotton +"Beat:"+Metronome.timeBeatFrame);
                //    //Debug.Log("Tecla W pulsada:");
                //    //player.GetComponent<Transform>().position -= new Vector3(0, -1, 0);
                //    eventAttack("w",direction);
                //}
                //else
                //{
                //    if (letter == "s")
                //    {
                //        //Debug.Log("Tecla S pulsada:");
                //        //player.GetComponent<Transform>().position -= new Vector3(0, 1, 0);
                //        eventAttack("s",direction);
                //    }
                //    else
                //    {
                //        if (letter == "a")
                //        {
                //            //Debug.Log("Tecla A pulsada:");
                //            //player.GetComponent<Transform>().position -= new Vector3(1, 0, 0);
                //            eventAttack("a",direction);
                //        }

                //        else
                //        {
                //            if (letter == "d")
                //            {
                //                //Debug.Log("Tecla D pulsada:");
                //                //player.GetComponent<Transform>().position -= new Vector3(-1, 0, 0);
                //                eventAttack("d",direction);
                //            }

                //        }
                //    }

                //}
                if ((timePushBotton >= ManagerBeat.timePulse) && (timePushBotton <= (ManagerBeat.timePulse + ManagerBeat.upperLimitPulse))){
                    flag_1 = true;
                    flag_2 = false;
                }
                else
                {
                    flag_2 = true;
                    flag_1 = false;
                }
                timePreviousPulse = ManagerBeat.timePulse;
            } 
        }

        //if (ManagerBeat.pulseCount==1)
        //{
        //    //attackEnemySC.CheckPossibilityEnemyAttack(letter);
        //    eventActionsController("nada", new Vector2(0,0), "Enemy");
        //}
            
    }

   
}
