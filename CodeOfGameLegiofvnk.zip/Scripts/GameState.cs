﻿using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

[CustomEditor(typeof(GameState))]
public class GameState_Editor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector(); // for other non-HideInInspector fields

        GameState script = target as GameState;
        script.AddFormation = EditorGUILayout.Toggle("AddFormation", script.AddFormation);
        if (script.AddFormation)
        {
            
            script.newFormation = (DataBaseFormation)EditorGUILayout.ObjectField("NewFormation",script.newFormation,typeof(DataBaseFormation),true);
            //p.objectReferenceValue = UnityEditor.EditorGUI.ObjectField(rect, "Any Object", p.objectReferenceValue, typeof(ScriptableObject), false);
        }
        else
        {
            script.formationSave = (DataBaseFormation)EditorGUILayout.ObjectField("FormationSave", script.formationSave, typeof(DataBaseFormation), true);
        }

    }

}
#endif
[ExecuteInEditMode]
public class GameState : MonoBehaviour
{
    [HideInInspector]
    public bool AddFormation;
    public DataBaseFormation newFormation;
    public DataBaseFormation formationSave;
    private DataBaseFormation formationDB;
    private GameObject formationGO;
    public static int formationWidht;
    public static int formationHeight;
    public string savePath;

#if UNITY_EDITOR
    private void OnEnable()
    {
        formationWidht = newFormation.width;
        formationHeight = newFormation.height;

    }
    private void Update()
    {
        if (AddFormation)
        {
            formationWidht=newFormation.width;
            formationHeight = newFormation.height;
        }
        else{
            formationWidht = formationSave.width;
            formationHeight = formationSave.height;
        }
    }
#endif
    void Start()
    {
        if (SceneManager.GetActiveScene().name != "Menu")
        {
            formationGO = GameObject.Find("Formation");
            
            if (formationGO != null)
            {
#if UNITY_EDITOR
                if (formationGO.GetComponent<SnapGrid>() != null && !Application.isPlaying)
                {

                    formationGO.GetComponent<SnapGrid>().enabled = true;
                }
                else
                {
                    formationGO.GetComponent<SnapGrid>().enabled = false;
                }
#endif
            }
            else
            {
                Debug.Log("Objeto formacion no encontrado");
            }
        }
        
        //selecTypeEnemySC = FindObjectOfType<SelecTypeEnemy>();
        
        if (SceneManager.GetActiveScene().name != "Menu" && Application.isPlaying)
        {
            LoadGame();
        }
    }

    //public void SaveGame()
    //{
    //    //SoldierSave[] soldiersSave = GameObject.FindObjectOfType<SoldierSave>();
    //    List<SoldierSave> data = new List<SoldierSave>();

    //    foreach (SoldierSave soldier in SelectedSoldiers.listSoldiers)
    //    {
    //        data.Add(SoldierData.GenerateData(soldier));
    //    }
    //    FileStream file = new FileStream(Application.streamingAssetsPath + "/save.bin", FileMode.OpenOrCreate, FileAccess.Write);
    //    file.SetLength(0);
    //    BinaryFormatter bf = new BinaryFormatter();
    //    bf.Serialize(file, data);
    //    file.Close();
    //}
    public void SaveGame()
    {
        formationDB = formationSave;
        formationDB.Save(savePath);
    }

    //private void LoadGame()
    //{
    //    if (File.Exists(Application.streamingAssetsPath + "/save.bin"))
    //    {
    //        FileStream file = new FileStream(Application.streamingAssetsPath + "/save.bin", FileMode.Open, FileAccess.Read);
    //        BinaryFormatter bf = new BinaryFormatter();
    //        List<SoldierSave> data = new List<SoldierSave>();

    //         data =bf.Deserialize(file) as List<SoldierSave>;

    //        foreach (SoldierSave soldier in data)
    //        {
    //            switch (soldier.getTypeSoldier()) {

    //                case "Legionario_Normal":
    //                    soldierDBSelected = (dataBaseSoldiers)AssetDatabase.LoadAssetAtPath("Assets/SO/LegionarioNormal.asset", typeof(dataBaseSoldiers));
    //                    break;

    //                case "Jefe":
    //                    soldierDBSelected=(dataBaseSoldiers)AssetDatabase.LoadAssetAtPath("Assets/SO/EnemyJefe.asset", typeof(dataBaseSoldiers));
    //                    break;
    //                case "Legionario_Pillum":
    //                    soldierDBSelected = (dataBaseSoldiers)AssetDatabase.LoadAssetAtPath("Assets/SO/LegionarioPillum.asset", typeof(dataBaseSoldiers));
    //                    break;

    //            }

    //            //formationGO.createSoldier(soldier,soldierDBSelected); 
    //            formationGO.GetComponent<Formation>().createSoldier(soldier, soldierDBSelected,formationGO.GetComponent<Transform>());
    //        }
    //        file.Close();
    //    }
    //}
    private void LoadGame()
    {
        if (AddFormation)
        {
            formationDB = newFormation;
        }
        else
        {
            formationDB = formationSave;
            formationDB.Load(savePath);
        }

        if (formationDB!=null && formationGO!=null)
        {
            for (int i = 0; i < formationDB.typeSoldier.Length; i++)
            {
                formationGO.GetComponent<Formation>().createSoldier(formationDB, formationDB.typeSoldier[i], formationGO.GetComponent<Transform>());
            }
        }
        else{
            Debug.Log("Objeto FormationDB no asignado en el script GameState");

        }
        
        
    }

}
