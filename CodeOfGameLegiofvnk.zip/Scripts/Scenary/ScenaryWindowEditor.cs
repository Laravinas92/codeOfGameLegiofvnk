﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
#if UNITY_EDITOR
using UnityEditor;


[ExecuteInEditMode]
public class ScenaryWindowEditor : MonoBehaviour
{
    private dataBaseScenary dataBaseScenary;
    private GameObject prefab;
    private GameObject ScenaryGO;
    private GameObject FormationGO;
    private GameObject lastChildOfScenaryGO;
    private GameObject[] destroyObjects;
    private GameObject[] obstacleEnemyObj;
    private List<GameObject> tempDestroyObjects = new List<GameObject>();
    public int width;
    public int height;
    private int auxWidth=0;
    private int auxHeight=0;
    private bool start;
    private bool next;

    public static Vector3 positionV0_0;
    public static Vector3 positionV1_1;

    public static List<Vector3> casillasListPosition = new List<Vector3>();
    public static List<GameObject> casillasListObj = new List<GameObject>();

    public static List<Vector3> casillasFreeListPosition = new List<Vector3>();
    public static List<Vector3> casillasListPositionFormation = new List<Vector3>();



    //[MenuItem("Window/Scenary Designer")]
    //static void OpenWindow()
    //{
    //    ScenaryWindowEditor window = (ScenaryWindowEditor)GetWindow(typeof(ScenaryWindowEditor));
    //    window.minSize = new Vector2(600,300);
    //    window.Show();
    //}

    private void OnEnable()
    {
        prefab = (GameObject)AssetDatabase.LoadAssetAtPath("Assets/Diseño/Prefabs/QuadCasilla.prefab", typeof(GameObject));
        dataBaseScenary = (dataBaseScenary)AssetDatabase.LoadAssetAtPath("Assets/SO/Scenary.asset", typeof(dataBaseScenary));
        ScenaryGO = GameObject.Find("Scenary");
        FormationGO = GameObject.Find("Formation");
        //FormationGO.GetComponent<SnapGrid>().enabled = true;

        if (ScenaryGO.transform.childCount != 0)
        {
            destroyObjects = GameObject.FindGameObjectsWithTag("Casilla");
            casillasListPosition.Clear();
            casillasListObj.Clear();
            

            for (int i = 0; i < destroyObjects.Length; i++)
            {
                //if (destroyObjects[i].gameObject.layer!=8)
                //{
                //    casillasFreeListPosition.Add(destroyObjects[i].transform.position);
                //}
                casillasListPosition.Add(destroyObjects[i].transform.position);
                casillasListObj.Add(destroyObjects[i]);
                
            }
            CalculateLimitTable(destroyObjects);
            ComposeLists();
        }
       
    }

    private void ComposeLists()
    {
        casillasFreeListPosition.Clear();

        if (ScenaryGO.transform.childCount != 0)
        {
            destroyObjects = GameObject.FindGameObjectsWithTag("Casilla");
            for (int j = 0; j < destroyObjects.Length; j++)
            {
                if (destroyObjects[j].gameObject.layer != 8 && destroyObjects[j].gameObject.layer != 10)
                {
                    casillasFreeListPosition.Add(destroyObjects[j].transform.position);
                }
            }
            //obstacleEnemyObj = GameObject.FindGameObjectsWithTag("EnemyLegionarioNormal");
            //piecesListObjAdd(destroyObjects, obstacleEnemyObj);
            //obstacleEnemyObj = GameObject.FindGameObjectsWithTag("EnemyLegionarioPillum");
            //piecesListObjAdd(destroyObjects, obstacleEnemyObj);
            //obstacleEnemyObj = GameObject.FindGameObjectsWithTag("EnemyJefe");
             obstacleEnemyObj = GameObject.FindGameObjectsWithTag("Enemy");
            piecesListObjAdd(destroyObjects, obstacleEnemyObj);
            piecesListRemoveFormation(destroyObjects);

            //obstacleEnemyObj = GameObject.FindGameObjectsWithTag("Obstacle");
            //piecesListObjAdd(destroyObjects, obstacleEnemyObj);
        }
    }

    private void piecesListRemoveFormation(GameObject[] destroyObjects)
    {
        int widthFor;
        int heightFor;
        if (FormationGO != null)
        {
            //FormationGO.GetComponent<SnapGrid>().enabled = true;
            widthFor = GameState.formationWidht;
            heightFor = GameState.formationHeight;
            //Debug.Log("widthFor: " + widthFor + "heightFor: " + heightFor);
            //Debug.Log("Entro" + FormationGO.transform.position);
            for (int x = 0; x < widthFor; x++)
            {
                for (int y = 0; y < heightFor; y++)
                {
                    for (int j = 0; j < destroyObjects.Length; j++)
                    {
                        // Debug.Log("Entro" + (FormationGO.transform.position.x + x) + "Y:" + (FormationGO.transform.position.y - y));
                        if ((FormationGO.transform.position.x + x) == destroyObjects[j].transform.position.x && (FormationGO.transform.position.y - y) == destroyObjects[j].transform.position.y)
                        {
                            casillasFreeListPosition.Remove(destroyObjects[j].transform.position);
                            break;
                        }
                    }
                }
            }
        }

        //for (int i = 0; i < casillasListPositionFormation.Count; i++)
        //{
        //    for (int j = 0; j < destroyObjects.Length; j++)
        //    {
        //        if (casillasListPositionFormation[i].x == destroyObjects[j].transform.position.x && casillasListPositionFormation[i].y == destroyObjects[j].transform.position.y)
        //        {
        //            Debug.Log(casillasListPositionFormation[i]);
        //            casillasFreeListPosition.Remove(destroyObjects[j].transform.position);

        //        }
        //    }
        //}
    }

    private void piecesListObjAdd(GameObject[] destroyObjects, GameObject[] obstacleEnemyObj)
    {
        for (int i = 0; i < obstacleEnemyObj.Length; i++)
        {
            for (int j = 0; j < destroyObjects.Length; j++)
            {
                if (obstacleEnemyObj[i].transform.position.x == destroyObjects[j].transform.position.x && obstacleEnemyObj[i].transform.position.y == destroyObjects[j].transform.position.y)
                {
                    casillasFreeListPosition.Remove(destroyObjects[j].transform.position);
                    break;
                }
            }
        }
    }



    //private void OnGUI()
    //{

    //    EditorGUILayout.BeginHorizontal();
    //    GUILayout.Label("Casilla");
    //    prefab = (GameObject)EditorGUILayout.ObjectField(prefab, typeof(GameObject),false);
    //    EditorGUILayout.EndHorizontal();

    //    EditorGUILayout.BeginHorizontal();
    //    GUILayout.Label("Width");
    //    width = EditorGUILayout.IntField(width);
    //    EditorGUILayout.EndHorizontal();

    //    EditorGUILayout.BeginHorizontal();
    //    GUILayout.Label("Height");
    //    height = EditorGUILayout.IntField(height);
    //    EditorGUILayout.EndHorizontal();

    //    auxWidth = 0;
    //    auxHeight = 0;



    //    if (GUILayout.Button("Create Table",GUILayout.Height(40)))
    //    {
    //        CreateTable();
    //        changed = true;
    //        destroyObjects = GameObject.FindGameObjectsWithTag("Casilla");
    //        for (int i = 0; i < destroyObjects.Length; i++)
    //        {
    //            if (destroyObjects[i].gameObject.GetComponent<SnapGrid>()==null)
    //            {
    //                destroyObjects[i].AddComponent<SnapGrid>();
    //            }
    //        }
    //    }
    //}

    private void Update()
    {
        if (width ==0 )
        {
            auxWidth = 0;
        }
        if (height ==0)
        {
            auxHeight = 0;
        }
        if (auxWidth != width || auxHeight != height)
        {
            CreateTable();
            destroyObjects = GameObject.FindGameObjectsWithTag("Casilla");
            casillasListPosition.Clear();
            casillasListObj.Clear();
            for (int i = 0; i < destroyObjects.Length; i++)
            {
                casillasListPosition.Add(destroyObjects[i].transform.position);
                casillasListObj.Add(destroyObjects[i]);
            }
            CalculateLimitTable(destroyObjects);
        }

        ComposeLists();
    }

    private void CreateTable()
    {
        tempDestroyObjects.Clear();

        if (ScenaryGO.transform.childCount != 0)
        {
            destroyObjects = GameObject.FindGameObjectsWithTag("Casilla");
            lastChildOfScenaryGO = ScenaryGO.transform.GetChild((ScenaryGO.transform.childCount - 1)).gameObject;
            //Debug.Log(lastChildOfScenaryGO.name);
            string[] str = lastChildOfScenaryGO.name.Split(char.Parse("_"));
            auxWidth = Int32.Parse(str[1]);
            auxHeight = Int32.Parse(str[2]);
            start = false;
        }

        int n = 0;
        if (auxWidth > width)
        {
            for (int i = auxWidth; i > width; i--)
            {
                for (int j = 0; j <= auxHeight; j++)
                {
                    for (int z = 0; z < destroyObjects.Length; z++)
                    {
                        if (destroyObjects[z].name == ("Casilla_" + i + "_" + j).ToString())
                        {
                            tempDestroyObjects.Add(destroyObjects[z]);
                            n++;
                            break;
                        }
                    }
                }
            }
            for (int z = 0; z < tempDestroyObjects.Count; z++)
            {
                DestroyImmediate(tempDestroyObjects[z]);
            }
            destroyObjects = GameObject.FindGameObjectsWithTag("Casilla");
        }

        if (auxHeight > height)
        {
            for (int i = 0; i <= auxWidth; i++)
            {
                for (int j = auxHeight; j > height; j--)
                {
                    for (int z = 0; z < destroyObjects.Length; z++)
                    {
                        if (destroyObjects[z].name == ("Casilla_" + i + "_" + j).ToString())
                        {
                            tempDestroyObjects.Add(destroyObjects[z]);
                            n++;
                            //DestroyImmediate(destroyObjects[z]);
                            break;
                        }
                    }
                }
            }
            for (int z = 0; z < tempDestroyObjects.Count; z++)
            {
                DestroyImmediate(tempDestroyObjects[z]);
            }
            destroyObjects = GameObject.FindGameObjectsWithTag("Casilla");

        }


        for (int i = 0; i < width; i++)
        {
            for (int j = 0; j < height; j++)
            {
                if (ScenaryGO.transform.childCount != 0 && start == false)
                {
                    for (int z = 0; z < destroyObjects.Length; z++)
                    {

                        if (destroyObjects[z].name == ("Casilla_" + (i + 1) + "_" + (j + 1)).ToString())
                        {
                            next = true;
                            break;
                        }
                    }
                }
                if (next == false)
                {
                    
                    GameObject temp = Instantiate(prefab, new Vector3(i, j, 1), Quaternion.identity);
                    temp.name = "Casilla_" + (i + 1) + "_" + (j + 1);
                    temp.tag = "Casilla";
                    temp.transform.SetParent(ScenaryGO.transform);
                    if (temp.gameObject.GetComponent<SelectMaterial>() == null)
                    {
                        temp.AddComponent<SelectMaterial>();
                    }
                    temp.GetComponent<MeshRenderer>().sharedMaterial = dataBaseScenary.materialLlanura_1;


                }
                next = false;
            }
        }
    }


    private void CalculateLimitTable(GameObject[] casillaGO)
    {

        if (ScenaryGO.transform.childCount != 0)
        {
            lastChildOfScenaryGO = ScenaryGO.transform.GetChild((ScenaryGO.transform.childCount - 1)).gameObject;
            string[] str = lastChildOfScenaryGO.name.Split(char.Parse("_"));
            auxWidth = Int32.Parse(str[1]);
            auxHeight = Int32.Parse(str[2]);
        }

        for (int i = 0; i < casillaGO.Length; i++)
        {
            if (casillaGO[i].name == "Casilla_1_1")
            {

                positionV0_0 = casillaGO[i].transform.position;

            }
            else
            {
                if (casillaGO[i].name == ("Casilla_" + auxWidth + "_" + auxHeight).ToString())
                {
                    positionV1_1 = casillaGO[i].transform.position;

                }
            }
        }
    }


    
}
#endif