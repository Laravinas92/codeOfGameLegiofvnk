﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;


[ExecuteInEditMode]
public class SnapGrid : MonoBehaviour
{
    private Vector3 gridSize = new Vector3(1, 1,0.99f);
    private List<Vector3> piecesListPosition = new List<Vector3>();
    private List<GameObject> piecesListObj = new List<GameObject>();
    //private TestFormation testFormationSC;
    Vector3[] lines = new Vector3[5];
    //GameObject formationGO;
    public static List<Vector3> casillasListTemp = new List<Vector3>();

    private void OnEnable()
    {
        piecesListObj.Add(gameObject);
        piecesListPosition.Add(gameObject.transform.position);
        //formationGO = GameObject.Find("Formation");
        //if (formationGO!=null)
        //{
            
        //    testFormationSC = formationGO.GetComponent<TestFormation>();
        //}
        
    }
    private void OnDestroy()
    {
        for (int i = 0; i < piecesListObj.Count; i++)
        {
            if (piecesListObj[i].gameObject.name == this.gameObject.name)
            {
                piecesListPosition.Remove(piecesListPosition[i]);
                piecesListObj.Remove(piecesListObj[i]);
            }
        }
    }
    void OnDrawGizmos()
    {
        if (this.name == "Formation" && this.transform.position.x > (ScenaryWindowEditor.positionV0_0.x - 1) && this.transform.position.x < (ScenaryWindowEditor.positionV1_1.x + 1) &&
            this.transform.position.y > (ScenaryWindowEditor.positionV0_0.y - 1) && this.transform.position.y < (ScenaryWindowEditor.positionV1_1.y + 1))
        {
            Handles.color = Color.white;
            Handles.DrawPolyLine(lines);
        }
    }
    

    private void LateUpdate()
    {
        //Debug.Log("Position V_1_1: " + ScenaryWindowEditor.positionV1_1 + "Position V_0_0: " + ScenaryWindowEditor.positionV0_0);
        if (this.transform.position.x > (ScenaryWindowEditor.positionV0_0.x - 1) && this.transform.position.x < (ScenaryWindowEditor.positionV1_1.x + 1) &&
            this.transform.position.y > (ScenaryWindowEditor.positionV0_0.y - 1) && this.transform.position.y < (ScenaryWindowEditor.positionV1_1.y + 1) && !this.CompareTag("Casilla") && gameObject.layer!=8)
        {
            SnapToGrid();
            if (this.name == "Formation")
            {
                DrawGridFormation();
            }
            

        }
        else
        {
            if (!this.CompareTag("Scenary") && !this.CompareTag("Casilla"))
            {
                this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, gridSize.z);
            }
            else
            {

                if (this.CompareTag("Casilla"))
                {
                    for (int i = 0; i < ScenaryWindowEditor.casillasListObj.Count; i++)
                    {
                        if (ScenaryWindowEditor.casillasListObj[i].name == this.name)
                        {
                            this.transform.position = ScenaryWindowEditor.casillasListPosition[i];
                            break;
                        }

                    }
                }
            }
        }
    }

    private void DrawGridFormation()
    {
        lines[0] = new Vector3(this.transform.position.x - 0.5f, this.transform.position.y + 0.5f,0.99f);
        lines[1] = new Vector3(this.transform.position.x - 0.5f + GameState.formationWidht, this.transform.position.y + 0.5f, 0.99f);
        lines[2] = new Vector3(this.transform.position.x - 0.5f + GameState.formationWidht, this.transform.position.y +0.5f- GameState.formationHeight, 0.99f);
        lines[3] = new Vector3(this.transform.position.x - 0.5f, this.transform.position.y + 0.5f - GameState.formationHeight, 0.99f);
        lines[4] = new Vector3(this.transform.position.x - 0.5f, this.transform.position.y + 0.5f, 0.99f);
        
        //drawLines = true;
    }

    private void SnapToGrid()
    {
        Vector3 position = new Vector3(
            Mathf.RoundToInt(this.transform.position.x / this.gridSize.x) * this.gridSize.x,
            Mathf.RoundToInt(this.transform.position.y / this.gridSize.y) * this.gridSize.y,
            gridSize.z
            ) ;
        CheckedPositionGrid(position);

    }


    private void CheckedPositionGrid(Vector3 position)
    {
        bool move = false;
        
        if (this.name=="Formation")
        {
            casillasListTemp.Clear();
           
            for (int x = 0; x < GameState.formationWidht; x++)
            {
                for (int y = 0; y < GameState.formationHeight; y++)
                {
                    for (int i = 0; i < ScenaryWindowEditor.casillasFreeListPosition.Count; i++)
                    {
                        if (ScenaryWindowEditor.casillasFreeListPosition[i].x == position.x+x && ScenaryWindowEditor.casillasFreeListPosition[i].y == position.y-y)
                        {
                            //Debug.Log(ScenaryWindowEditor.casillasFreeListPosition[i]);
                            casillasListTemp.Add(ScenaryWindowEditor.casillasFreeListPosition[i]);
                        }
                    }
                }
                
            }
            if (casillasListTemp.Count == (GameState.formationHeight * GameState.formationWidht))
            {
                ScenaryWindowEditor.casillasListPositionFormation = casillasListTemp;
                move = true;
            }
        }
        else
        {
            for (int i = 0; i < ScenaryWindowEditor.casillasFreeListPosition.Count; i++)
            {
                if (ScenaryWindowEditor.casillasFreeListPosition[i].x == position.x && ScenaryWindowEditor.casillasFreeListPosition[i].y == position.y)
                {
                    move = true;
                    break;
                }
            }
        }
        
        if (move == true)
        {
            for (int i=0;i<piecesListObj.Count;i++)
            {
                if (piecesListObj[i].gameObject.name==this.gameObject.name)
                {
                    piecesListPosition[i] = position;
                    this.transform.position = position;
                }
            }
        }
        else
        {
            for (int j = 0; j < piecesListObj.Count; j++)
            {
                if (piecesListObj[j].gameObject.name == this.gameObject.name)
                {
                    this.transform.position = new Vector3(piecesListPosition[j].x, piecesListPosition[j].y,gridSize.z);
                    break;
                }
            } 
        }
    }  
}
#endif