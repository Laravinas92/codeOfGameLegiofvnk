﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
#if UNITY_EDITOR
using UnityEditor;

[CanEditMultipleObjects]
[CustomEditor(typeof(SelectMaterial))]
public class SelectMaterial_Editor : Editor
{
    private SelectMaterial script;
    private SerializedProperty m_piece;
    private SerializedProperty m_transitablePiece;
    private SerializedProperty m_Reward;
    private SerializedProperty m_Destroyable;
    private SerializedProperty m_allowAttack;
    private SerializedProperty m_NotWalkeable;
    private SerializedProperty m_GiveReward;
    private SerializedProperty m_lifeObject;
    //private SerializedProperty m_maxLifeObject;
    private SerializedProperty m_rewardPiece;

    private void OnEnable()
    {
        script = target as SelectMaterial;
        // Setup the SerializedProperties
        m_piece = serializedObject.FindProperty("piece");
        m_transitablePiece = serializedObject.FindProperty("transitablePiece");
        m_Reward = serializedObject.FindProperty("Reward");
        m_Destroyable = serializedObject.FindProperty("Destroyable");
        m_allowAttack = serializedObject.FindProperty("allowAttack");
        m_NotWalkeable = serializedObject.FindProperty("NotWalkeable");
        m_GiveReward = serializedObject.FindProperty("GiveReward");
        m_lifeObject = serializedObject.FindProperty("lifeObject");
        //m_maxLifeObject = serializedObject.FindProperty("maxLifeObject");
        m_rewardPiece = serializedObject.FindProperty("rewardPiece");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        
        if (script.Layer == 9)
        {
            EditorGUILayout.PropertyField(m_transitablePiece);
            EditorGUILayout.PropertyField(m_GiveReward);
            
            if (script.GiveReward)
            {
                EditorGUILayout.PropertyField(m_rewardPiece);
            }

            script.NotWalkeable = false;
            script.Destroyable = false;
            script.Reward = false;
            script.allowAttack = false;
        }
        else
        {
            EditorGUILayout.PropertyField(m_piece);
            EditorGUILayout.PropertyField(m_transitablePiece);
            EditorGUILayout.PropertyField(m_Reward);

            if (!script.Reward)
            {
                EditorGUILayout.PropertyField(m_allowAttack);
                EditorGUILayout.PropertyField(m_Destroyable);
                EditorGUILayout.PropertyField(m_NotWalkeable);
                if (script.Destroyable) // if bool is true, show other fields
                {
                    //EditorGUILayout.PropertyField(m_maxLifeObject);
                    EditorGUILayout.PropertyField(m_lifeObject);
                    EditorGUILayout.PropertyField(m_GiveReward);
                    script.NotWalkeable = true;
                    
                    if (script.GiveReward)
                    {
                        EditorGUILayout.PropertyField(m_rewardPiece, true);
                    }
                }
                else
                {
                    script.Destroyable = false;
                    script.GiveReward = false;
                }
            }
            else
            {
                script.NotWalkeable = false;
                script.GiveReward = false;
                script.Destroyable = false;
                script.allowAttack = false;

            }
        }

        serializedObject.ApplyModifiedProperties();
    }
}

[ExecuteInEditMode]
public class SelectMaterial : MonoBehaviour
{
    public enum typePiece
    {
        Llanura_1,
        Llanura_2,
        LlanuraElevacion,
        Pared,
        Arbol_Llanura_1,
        Arbol_Llanura_2,
        Agua,
        Camino,
        Camino1,
        Camino2,
        Camino3,
        Camino4,
        Camino5,
        Camino6,
        Camino7,
        Camino8,
        PuentePiedraL,
        PuentePiedraR,
        PuenteMadera,
        Columna_Llanura_1,
        Columna_Llanura_2,
        Empalizada_Llanura_1,
        Empalizada_Llanura_2,
        Barril_Llanura_1,
        Barril_Llanura_2,
        Tienda,
        Hoguera,
        Planta1,
        Planta2,
        Flores,
        Tocon,
        Tocon2,
        AcantiladoDM,
        AcantiladoDL,
        AcantiladoDR,
        AcantiladoL1,
        AcantiladoL2,
        AcantiladoR1,
        AcantiladoR2,
        AcantiladoUM1,
        AcantiladoUM2,
        AcantiladoUL1,
        AcantiladoUL2,
        AcantiladoUR1,
        AcantiladoUR2,
        AcantiladoL1X,
        AcantiladoL2X,
        AcantiladoR1X,
        AcantiladoR2X,
        Pan,
        Manzana,
        Pollo,
        Queso,
        HierbaCurativa,
        Dinero1,
        Dinero2,
        Dinero3,
        Dinero1_Llanura1,
        Dinero2_Llanura1,
        Dinero3_Llanura1,
        Dinero1_Llanura2,
        Dinero2_Llanura2,
        Dinero3_Llanura2
    }
    public enum TransitablePieces
    {
        Llanura_1,
        Llanura_2,
        Camino,
        PuentePiedra,
        PuenteMadera,
        Planta1,
        Planta2,
        Flores
    }

    public enum RewardPiece
    {
        Pan,
        Manzana,
        Pollo,
        Queso,
        HierbaCurativa,
        Dinero1,
        Dinero2,
        Dinero3,
        Dinero1_Llanura1,
        Dinero2_Llanura1,
        Dinero3_Llanura1,
        Dinero1_Llanura2,
        Dinero2_Llanura2,
        Dinero3_Llanura2
    }

    [HideInInspector]
    public int Layer;
    [HideInInspector]
    public typePiece piece;
    [HideInInspector]
    public TransitablePieces transitablePiece;
    [HideInInspector]
    public bool Reward;
    [HideInInspector]
    public bool Destroyable;
    [HideInInspector]
    public bool NotWalkeable;
    [HideInInspector]
    public bool allowAttack;
    [HideInInspector]
    public bool GiveReward;
    [HideInInspector]
    public float lifeObject;
    //[HideInInspector]
    //public int maxLifeObject;
    [HideInInspector]
    public RewardPiece rewardPiece;

    private bool tempNotWalkeable;
    private bool tempReward;
    private string tempPiece;
    private SO_Manager SO_ManagerSC;
 
    private void OnEnable()
    {
        Layer = gameObject.layer;
        tempPiece = piece.ToString();
        SO_ManagerSC = FindObjectOfType<SO_Manager>();
    }
    private void Update()
    {
        if (tempPiece != piece.ToString() && gameObject.layer!=9)
        {
            if (SO_ManagerSC != null)
            {
                SO_ManagerSC.UpdateMaterialPiece(this.gameObject, piece.ToString());
                tempPiece = piece.ToString();
            }
            else
            {
                Debug.Log("Objeto SO_Manager no asignado en script FindObjects");
            }
        }

        if (NotWalkeable ==true && gameObject.layer!=8 && gameObject.layer != 9)
        {
            gameObject.layer = 8;
            Layer = 8;
        }
        else
        {
            if (NotWalkeable==false && tempNotWalkeable!=NotWalkeable && gameObject.layer != 9)
            {
                gameObject.layer = 0;
                Layer = 0;
            }
        }
        if (Reward==true && tempReward!=Reward && gameObject.layer != 8 && gameObject.layer != 9)
        {
            gameObject.layer = 10;
        }
        else
        {
            if (!Reward && tempReward != Reward && gameObject.layer != 8 && gameObject.layer != 9)
            {
                gameObject.layer = 0;
            }
            
        }

        tempReward = Reward;
        tempNotWalkeable = NotWalkeable;
    }
    
}
#endif