﻿using System;
using System.Collections;
using System.Collections.Generic;
using Pathfinding;
using UnityEngine;

public class EnemyIA : MonoBehaviour
{
    Seeker seeker;
    Path path;
    List<Vector3> vectorReturn = new List<Vector3>();
    void Start()
    {
        //seeker = FindObjectOfType<Seeker>();
        seeker = GetComponent<Seeker>();
    }

    // Update is called once per frame
    public List<Vector3> CheckBestSoldierToApprox(Vector3 posSoldier,GameObject enemyGo)
    {
        //Debug.Log("SEEK_Vector: "+ this.gameObject.name+"Position: "+ this.transform.position);
        //seeker.CancelCurrentPathRequest(true);

        //Path p = ABPath.Construct(this.transform.position,posSoldier);

        //seeker.StartPath(p, OnPathComplete);
        Vector3 positionEnemy = this.transform.position;

        //seeker.pathCallback += OnPathComplete;
        //if (path == null)
        //{
        //   // Debug.Log("Holaaaa");
        //}

        NodePenalty(true);
        //Path path =seeker.GetNewPath(this.transform.position, posSoldier,OnPathComplete); 
        //do
        //{
            Path aux_path = seeker.StartPath(positionEnemy, posSoldier, OnPathComplete);
            aux_path.BlockUntilCalculated();
        //recalculatePath = CheckNextoPositionIfEnemy(path.vectorPath[1]);
        //var node = AstarPath.active.GetNearest(path.vectorPath[1]).node;
        //Debug.Log(node.Area);
        //node.Penalty = 20000;

        //} while (recalculatePath == true);
        //GraphNode renode = AstarPath.active.GetNearest(path.vectorPath[1]).node;
        //renode.Penalty = 0;
        NodePenalty(false);
        vectorReturn.Clear();
        if (path != null)
        {
            vectorReturn = path.vectorPath;
        }
        else
        {
            vectorReturn.Add(new Vector3(-5,-5,-5));
        }
        
        return vectorReturn;
    }

    private void NodePenalty(bool asignnedPenalty)
    {
        for (int i = 0; i < Soldier.listEnemies.Count; i++)
        {
            if (Soldier.listEnemies[i].SoldierGO.name != this.gameObject.name)
            {
                GraphNode node = AstarPath.active.GetNearest(new Vector3(Soldier.listEnemies[i].PositionX, Soldier.listEnemies[i].PositionY, 1f)).node;
                if (asignnedPenalty == true)
                {
                    node.Penalty = 200;
                }
                else
                {
                    node.Penalty = 0;
                }
            }
           
           
        }
    }

    //private bool CheckNextoPositionIfEnemy(Vector3 nextPoint)
    //{
    //    for (int i=0;i<Soldier.listEnemies.Count;i++)
    //    {
            
    //        if (Soldier.listEnemies[i].PositionX==nextPoint.x && Soldier.listEnemies[i].PositionY==nextPoint.y)
    //        {
    //            Debug.Log("NextPoint: " + nextPoint);
    //            return true;
    //        }
    //    }
    //    return false;
    //}

    private void OnPathComplete(Path p)
    {
        if (!p.error)
        {
            path = p;

        }
        else
        {
            path = null;
            Debug.Log("Path con errores");
        }
    }
    public void OnDisable()
    {
        seeker.pathCallback -= OnPathComplete;
    }

}
