﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestEnemy : MonoBehaviour
{
    public bool ModoDios;
    public bool NotMove;
    public float life;
    private bool change = false;
    private bool tempModoDios = false;
    private int caseNumber = 0;
    private float InfinityLife = 100000;
    private void Update()
    {
        if (ModoDios == true && ModoDios!=tempModoDios)
        {
            caseNumber = 2;
            change = true;
        }
        else
        {
            if (ModoDios == false )
            {
                caseNumber = 1;
                change = true;
            }
        }
        if (change == true && ModoDios !=tempModoDios)
        {
            UpdateLifeEnemy(caseNumber);
            change = false;
        }
        tempModoDios = ModoDios;
    }

    private void UpdateLifeEnemy(int caseNumber)
    {
        for (int i = 0; i < Soldier.listEnemies.Count; i++)
        {
            if (Soldier.listEnemies[i].SoldierGO.name == this.name)
            {
                switch (caseNumber)
                {
                    case 1:
                        life = Soldier.listEnemies[i].LifeDB;
                        Soldier.listEnemies[i].Life = Soldier.listEnemies[i].LifeDB;
                        break;
                    case 2:
                        life = InfinityLife;
                        Soldier.listEnemies[i].Life = InfinityLife;
                        break;
                }
            }
        }
    }
}
