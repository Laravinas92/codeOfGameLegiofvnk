﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TesteoSoldier : MonoBehaviour
{
    public bool SoldierDied;
    public float life;
    private void Update()
    {
        if (this.GetComponent<TesteoSoldier>().SoldierDied == true )
        {
            UpdateLifeListSoldier(2);
        }  
        
        
    }
    private void UpdateLifeListSoldier(int caseNumber)
    {
        for (int i=0; i<Soldier.listSoldiers.Count;i++)
        {
            if (Soldier.listSoldiers[i].SoldierGO.name==this.name)
            {
                switch (caseNumber)
                {
                    case 1:
                        life = Soldier.listSoldiers[i].LifeDB;
                        Soldier.listSoldiers[i].Life = Soldier.listSoldiers[i].LifeDB;
                        Soldier.listSoldiers[i].SoldierGO.SetActive(true);
                        break;
                    case 2:
                        life = 0;
                        Soldier.listSoldiers[i].Life = 0;
                        Soldier.listSoldiers[i].Id = 0;
                        Soldier.listSoldiers[i].SoldierGO.SetActive(false);
                        break;
                }
            }
        }
    }
}
