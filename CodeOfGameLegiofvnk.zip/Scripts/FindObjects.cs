﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class FindObjects : MonoBehaviour
{
    public GameObject scenaryGO;
    public GameObject SO_ManagerGO;
    public GameObject textMoney;
    private float actualMoney;
    private Formation formationSC;
    private GameObject formationGO;
    public static List<GameObject> listIntransitables = new List<GameObject>();
    public static List<Items> listReward = new List<Items>();
    //private DataBaseItems dataBaseItemsSC;
    private List<GameObject> tempListIntransitables = new List<GameObject>();


    void Start()
    {
        //dataBaseItemsSC= (DataBaseItems)AssetDatabase.LoadAssetAtPath("Assets/SO/Items.asset", typeof(DataBaseItems));
        //formationSC = FindObjectOfType<Formation>();
        //scenaryGO = GameObject.Find("Scenary");
        if (textMoney!=null)
        {
            textMoney.GetComponent<TextMeshProUGUI>().text = actualMoney.ToString();
        }
        else
        {
            Debug.Log("No se ha asignado variable textMoney en el inspector, script FindObjects");
        }

        formationGO = GameObject.Find("Formation");
        if (formationGO!=null)
        {
            formationSC = formationGO.GetComponent<Formation>();
        }
        else
        {
            Debug.Log("No se encuentra obejto formation en el inspector, script FindObjects");
        }
        
        if (scenaryGO == null)
        {
            Debug.Log("Objeto scenary no asignado en script FindObjects");
        }
        else
        {
            if (scenaryGO.transform.childCount != 0)
            {
                for (int i = 0; i < scenaryGO.transform.childCount; i++)
                {
                    if (scenaryGO.transform.GetChild(i).gameObject.layer == 8)
                    {
                        listIntransitables.Add(scenaryGO.transform.GetChild(i).gameObject);
                        if (scenaryGO.transform.GetChild(i).gameObject.GetComponent<SelectMaterial>().Destroyable==true)
                        {
                            GetComponent<ModifyIconLife>().PutSpriteLife((int)scenaryGO.transform.GetChild(i).gameObject.GetComponent<SelectMaterial>().lifeObject, scenaryGO.transform.GetChild(i).gameObject);
                        }
                    }
                    else
                    {
                        if (scenaryGO.transform.GetChild(i).gameObject.layer == 4)
                        {
                            //Añadir a lista de agua
                        }
                        else
                        {
                            if (scenaryGO.transform.GetChild(i).gameObject.GetComponent<SelectMaterial>().Reward == true)
                            {
                                
                                if (SO_ManagerGO!=null)
                                {
                                    SO_ManagerGO.GetComponent<SO_Manager>().AddItemToList(scenaryGO.transform.GetChild(i).gameObject, false);
                                }
                                else
                                {
                                    Debug.Log("Objeto SO_Manager no asignado en script FindObjects");
                                }
                                
                            }
                        }
                    }
                }
            }
        }
    }

    

    public void UdateLifeObject(float damage)
    {
        bool died;
        for (int j = 0; j < listIntransitables.Count; j++)
        {
            died = false;
            for (int i = 0; i < dataBaseAttacks.listObjectToUpdateLive.Count; i++)
            {
                if (listIntransitables[j].name == dataBaseAttacks.listObjectToUpdateLive[i].name)
                {
                    if (listIntransitables[j].GetComponent<SelectMaterial>()!=null)
                    {
                        listIntransitables[j].GetComponent<SelectMaterial>().lifeObject -= damage;
                        if (listIntransitables[j].GetComponent<SelectMaterial>().lifeObject<=0)
                        {
                            died = true;
                            listIntransitables[j].GetComponent<SelectMaterial>().lifeObject = 0;
                            GetComponent<ModifyIconLife>().DesactiveIconLife(listIntransitables[j].GetComponent<SelectMaterial>().lifeObject, listIntransitables[j]);
                            if (listIntransitables[j].GetComponent<SelectMaterial>().GiveReward==true)
                            {
                                ChangeObjectOnScene(listIntransitables[j], true);
                            }
                            else
                            {
                                ChangeObjectOnScene(listIntransitables[j], false);
                            }

                        }
                        else
                        {
                            GetComponent<ModifyIconLife>().DesactiveIconLife(listIntransitables[j].GetComponent<SelectMaterial>().lifeObject, listIntransitables[j]);
                        }
                    }
                    break;
                }
            }
            if (died == false)
            {
                tempListIntransitables.Add(listIntransitables[j]);
            }
        }
        listIntransitables = new List<GameObject>(tempListIntransitables);
        tempListIntransitables.Clear();
    }

    private void ChangeObjectOnScene(GameObject objectGO,bool pieceSoldier)
    {
        if (objectGO.GetComponent<SelectMaterial>().GiveReward == true)
        {
            
            if (SO_ManagerGO != null)
            {
                SO_ManagerGO.GetComponent<SO_Manager>().UpdateMaterialPiece(objectGO, objectGO.GetComponent<SelectMaterial>().rewardPiece.ToString());
                SO_ManagerGO.GetComponent<SO_Manager>().AddItemToList(objectGO, false);
                objectGO.GetComponent<SelectMaterial>().Destroyable = false;
                objectGO.GetComponent<SelectMaterial>().NotWalkeable = false;
                objectGO.GetComponent<SelectMaterial>().GiveReward = false;
            }
            else
            {
                Debug.Log("Objeto SO_Manager no asignado en script FindObjects");
            }
        }
        else
        {
            if (pieceSoldier==true)
            {
                objectGO.transform.SetParent(null);
                objectGO.SetActive(false);
            }
            else
            {
                if (SO_ManagerGO != null)
                {
                    SO_ManagerGO.GetComponent<SO_Manager>().UpdateMaterialPiece(objectGO,objectGO.GetComponent<SelectMaterial>().transitablePiece.ToString());
                }
                else
                {
                    Debug.Log("Objeto SO_Manager no asignado en script FindObjects");
                }
            }

            
        }
        
        objectGO.GetComponent<Collider2D>().enabled = false;
        AstarPath.active.UpdateGraphs(objectGO.GetComponent<Collider2D>().bounds);
    }


    public void FoundReward(List<Items> items,List<Soldier> soldiersUpdate)
    {
        bool takeReward = false;
        for (int i=0;i<items.Count;i++)
        {
            if (formationSC != null)
            {
                if (items[i].NameItem != "Dinero1" && items[i].NameItem != "Dinero2" && items[i].NameItem != "Dinero3")
                {
                    takeReward = formationSC.UpdateLifeSoldier(Soldier.listSoldiers[0], soldiersUpdate[i], 2, items[i].Affectation);
                }
                else
                {
                    actualMoney += items[i].Affectation;
                    textMoney.GetComponent<TextMeshProUGUI>().text = actualMoney.ToString();
                    takeReward = true;
                }
                
            }
            else
            {
                Debug.Log("Objeto formación no asignado en script FindObjects");
            }
            if (takeReward)
            {
                if (items[i].PieceSoldier == true)
                {

                    ChangeObjectOnScene(items[i].RewardGO, true);
                }
                else
                {
                    ChangeObjectOnScene(items[i].RewardGO, false);
                }
                listReward.Remove(items[i]);


            }
            
        }
        
          
        
        
    }
}
