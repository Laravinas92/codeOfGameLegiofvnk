﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewSoldier", menuName = "createSoldier")]
public class dataBaseSoldiers : PersistentScriptableObject
{
    [Tooltip("Variable que indica la vida del soldado")]
    public float life;
    [Tooltip("Variable que permite indicar el tipo de soldado:legionario,lancero....")]
    public string typeSoldier;
    [Tooltip("Variable que permite indicar el nivel de fuerza")]
    public int strength;
    [Tooltip("Variable que permite añadir tipos de ataque al soldado")]
    public dataBaseAttacks typeAttacks;
    [Tooltip("Variable que indica una habilidad del soldado, como andar por agua o destruir terrenos especiales")]
    public string[] specialAbility;
    [Tooltip("Icono que se emplea para representar al soldado aliado pertinente")]
    public GameObject iconUnit;
    [Tooltip("Material que se asigna para representar al soldado aliado pertinente")]
    public Material materialUnit;
    [Tooltip("Icono que se emplea para representar al soldado enemigo pertinente")]
    public GameObject iconEnemy;
    [Tooltip("Material que se asigna para representar al soldado enemigo pertinente")]
    public Material materialEnemy;
    [Tooltip("Sprite que se emplea para representar al soldado aliado pertinente,se emplea para la pantalla de menu,permite mostrar los soldados existentes y elegir soldados a formar")]
    public Sprite spriteUnit;
    private int id;
    private float positionX;
    private float positionY;

    

    //AÑADIR HABILIDAD A LA INSTANCIA, CUANDO SE RESUELVA LA DUDA
    //public void Init(float live, dataBaseAttacks[] typeAttacks, Sprite iconUnit, float positionX, float positionY, int id)
    //{
    //    this.live = live;
    //    this.typeAttacks = typeAttacks;
    //    this.iconUnit = iconUnit;
    //    this.positionX = positionX;
    //    this.positionY = positionY;
    //    this.id = id;

    //}
    //public static dataBaseSoldiers CreateInstance(float live, dataBaseAttacks[] typeAttacks, Sprite iconUnit, float positionX, float positionY, int id)
    //{
    //    dataBaseSoldiers dataBaseSoldier = ScriptableObject.CreateInstance<dataBaseSoldiers>();
    //    dataBaseSoldier.Init(live,typeAttacks, iconUnit,positionX,positionY,id);
    //    return dataBaseSoldier;
    //}


}



