﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewItem", menuName = "createItems")]
public class DataBaseItems : ScriptableObject
{
    [Tooltip("Variable que permite añadir Items")]
    public Item[] item;
}

[System.Serializable]
public struct Item
{
    [Tooltip("Variable que indica el nombre del Item")]
    public string nameObject;
    [Tooltip("Variable que indica la cantidad de vida o munición pérdida/ganada cuando alcanzas el Item, cero ó más")]
    public float affectation;
}

