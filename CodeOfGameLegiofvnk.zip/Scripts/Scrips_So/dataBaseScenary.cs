﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewScenary", menuName = "createScenary")]
public class dataBaseScenary : ScriptableObject
{
    public Material materialLlanura_1;
    public Material materialLlanura_2;
    public Material materialLlanuraElevacion;
    public Material materialPared;
    public Material materialArbol_Llanura_1;
    public Material materialArbol_Llanura_2;
    public Material materialAgua;
    public Material materialCamino;
    public Material materialCamino1;
    public Material materialCamino2;
    public Material materialCamino3;
    public Material materialCamino4;
    public Material materialCamino5;
    public Material materialCamino6;
    public Material materialCamino7;
    public Material materialCamino8;
    public Material materialPuentePiedraR;
    public Material materialPuentePiedraL;
    public Material materialPuenteMadera;
    public Material materialColumna_Llanura_1;
    public Material materialColumna_Llanura_2;
    public Material materialEmpalizada_Llanura_1;
    public Material materialEmpalizada_Llanura_2;
    public Material materialBarril_Llanura_1;
    public Material materialBarril_Llanura_2;
    public Material materialTienda;
    public Material materialHoguera;
    public Material materialPlanta1;
    public Material materialPlanta2;
    public Material materialFlores;
    public Material materialTocon;
    public Material materialTocon2;
    public Material materialAcantiladoDM;
    public Material materialAcantiladoDL;
    public Material materialAcantiladoDR;
    public Material materialAcantiladoL1;
    public Material materialAcantiladoL2;
    public Material materialAcantiladoR1;
    public Material materialAcantiladoR2;
    public Material materialAcantiladoUM1;
    public Material materialAcantiladoUM2;
    public Material materialAcantiladoUL1;
    public Material materialAcantiladoUL2;
    public Material materialAcantiladoUR1;
    public Material materialAcantiladoUR2;
    public Material materialAcantiladoL1X;
    public Material materialAcantiladoL2X;
    public Material materialAcantiladoR1X;
    public Material materialAcantiladoR2X;
    public Material materialPan;
    public Material materialManzana;
    public Material materialPollo;
    public Material materialQueso;
    public Material materialHierbaCurativa;
    public Material materialDinero1_Llanura1;
    public Material materialDinero2_Llanura1;
    public Material materialDinero3_Llanura1;
    public Material materialDinero1_Llanura2;
    public Material materialDinero2_Llanura2;
    public Material materialDinero3_Llanura2;
    public Material materialDinero1;
    public Material materialDinero2;
    public Material materialDinero3;


}
