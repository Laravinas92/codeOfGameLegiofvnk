﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewAttack", menuName = "createAttack")]
public class dataBaseAttacks : ScriptableObject
{
    [Tooltip("Número entero que indica la distancia a la afecta el ataque o distancia a la que se encuentra el enemigo")]
    public int maxDistanceAtack;
    public int minDistanceAtack;
    //[Tooltip("Número real que permite indicar la cantidad de vida que pierde un enemigo cuando es atacado por este tipo de ataque en dicha dirección")]
    //public float damageAtack;


    private List<Soldier> listToCompare= new List<Soldier>();
    private List<Soldier> listOfAliados = new List<Soldier>();
    public static List<Soldier> listSoldierToUpdateLive = new List<Soldier>();
    public static List<GameObject> listObjectToUpdateLive = new List<GameObject>();

    public bool CheckAttackCuerpoACuerpo(float positionX,float positionY,Vector2 direction,int maxDistanceAtt ,string typeSoldier) {

        listSoldierToUpdateLive.Clear();
        listObjectToUpdateLive.Clear();
        if (typeSoldier == "Soldier")
        {
            
            listToCompare= Soldier.listEnemies;
        }
        else
        {
            listToCompare = Soldier.listSoldiers;
        }
        for (int i = 0; i < listToCompare.Count; i++)
        {
            if (typeSoldier == "Soldier")
            {
                //Debug.Log("PositionSoldierX:" + (positionX - (direction.x * maxDistanceAtt)) + "PositionSoldierY:" + (positionY - (direction.y * maxDistanceAtt)));
                //Debug.Log("PositionEnemyX:" + listToCompare[i].PositionX + "PositionEnemyY:" + listToCompare[i].PositionY);
            }
            if (listToCompare[i].Id != 0)
            {
                //Debug.Log(listToCompare[i].SoldierGO.name);
                //Debug.Log("PositionSoldierX:" + (positionX - (direction.x * maxDistanceAtt)) + "PositionSoldierY:" + (positionY - (direction.y * maxDistanceAtt)));
                //Debug.Log("PositionEnemyX:" + listToCompare[i].PositionX + "PositionEnemyY:" + listToCompare[i].PositionY);
                if (((positionX - (direction.x*maxDistanceAtt)) == listToCompare[i].PositionX) && ((positionY - (direction.y*maxDistanceAtt)) == listToCompare[i].PositionY))
                {   
                
                    //Debug.Log("ATAQUE CUERPO A CUERPO"+ listToCompare[i].SoldierGO.name);
                    listSoldierToUpdateLive.Add(listToCompare[i]);
                    return true;
                }
                    
            }
        }
        if (typeSoldier == "Soldier")
        {
            for (int i = 0; i < FindObjects.listIntransitables.Count; i++)
            {

                //Debug.Log("PositionSoldierX:"+ (positionX - (direction.x * maxDistanceAtt))+ "PositionSoldierY:"+(positionY - (direction.y * maxDistanceAtt)));
                //Debug.Log("PositionEnemyX:"+ listToCompare[i].PositionX+"PositionEnemyY:"+ listToCompare[i].PositionY);
                if (((positionX - (direction.x * maxDistanceAtt)) == FindObjects.listIntransitables[i].transform.position.x) && ((positionY - (direction.y * maxDistanceAtt)) == FindObjects.listIntransitables[i].transform.position.y))
                {
                    if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>() != null)
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().Destroyable == true)
                        {
                            //Debug.Log("ATAQUE CUERPO A CUERPO A ÓBSTACULO");
                            listObjectToUpdateLive.Add(FindObjects.listIntransitables[i]);
                            return true;
                        }
                    }
                    //listToCompare[i].Life = (listToCompare[i].Life - damage);
                }
            }
        }
        return false;
    }

    public bool CheckAttackDistance(float positionX, float positionY, Vector2 direction,int minDistanceAtt, int maxDistanceAtt, string typeSoldier)
    {
        bool enemieToDistance = false;
        int auxDistance = 0;
        //int auxEnemy = 0;
        listSoldierToUpdateLive.Clear();
        listObjectToUpdateLive.Clear();
        if (typeSoldier == "Soldier")
        {
            listToCompare = Soldier.listEnemies;
        }
        else
        {
            listToCompare = Soldier.listSoldiers;
        }
        //for (int j = maxDistanceAtack; j >= minDistanceAtack; j++)
        for (int j = minDistanceAtack; j <= maxDistanceAtack; j++)
        {
            for (int i = 0; i < listToCompare.Count; i++)
            {
                if (listToCompare[i].Id!=0)
                {
                    if (((positionX - (direction.x * j)) == listToCompare[i].PositionX) && ((positionY - (direction.y * j)) == listToCompare[i].PositionY))
                    {
                        enemieToDistance = true;
                        auxDistance = j;
                        //auxEnemy = i;
                        listSoldierToUpdateLive.Add(listToCompare[i]);
                        break;
                    }

                }
                
            }
            if (enemieToDistance == true) { break; }
        }
        if (enemieToDistance == false)
        {
            auxDistance = maxDistanceAtt;
        }
        
        for (int j = minDistanceAtt; j <= auxDistance; j++)
        {
            for (int i = 0; i < FindObjects.listIntransitables.Count; i++)
            {
                if (((positionX - (direction.x * j)) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x) && ((positionY - (direction.y * j)) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y))
                {
                    if (typeSoldier == "Soldier" && FindObjects.listIntransitables[i].GetComponent<SelectMaterial>() != null)
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().Destroyable == true)
                        {
                            //Debug.Log("ATAQUE DISTANCIA A OBJETO DESTRUIBLE");
                            listObjectToUpdateLive.Add(FindObjects.listIntransitables[i]);
                            if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().allowAttack==false)
                            {
                                listSoldierToUpdateLive.Clear();
                            }
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().allowAttack == false)
                        {
                            listSoldierToUpdateLive.Clear();
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                        
                    }
                }
            }
        }
        if (enemieToDistance == true)
        {
            //Debug.Log("ATAQUE DISTANCIA A SOLDADO ENEMIGO");
            //listToCompare[auxEnemy].Life = (listToCompare[auxEnemy].Life - damage);
            //Debug.Log(listToCompare[auxEnemy].IconUnit.name);
            //listSoldierToUpdateLive.Add(listToCompare[auxEnemy]);
            return true;
        }
        return false;
    }
    public bool CheckAttackEstocada(float positionX, float positionY, Vector2 direction, int minDistanceAtt, int maxDistanceAtt, string typeSoldier)
    {
        bool enemieToDistance = false;
        int auxDistance = 0;
        //int auxEnemy = 0;
        listSoldierToUpdateLive.Clear();
        listObjectToUpdateLive.Clear();

        if (typeSoldier == "Soldier")
        {
            listToCompare = Soldier.listEnemies;
            listOfAliados = Soldier.listSoldiers;
        }
        else
        {
            listToCompare = Soldier.listSoldiers;
            listOfAliados = Soldier.listEnemies;
        }

        for (int j = maxDistanceAtt; j >= minDistanceAtt; j--)
        {
            for (int i = 0; i < listToCompare.Count; i++)
            {
                if(listToCompare[i].Id != 0)
                {
                    if (((positionX + (direction.x * j)) == listToCompare[i].PositionX) && ((positionY + (direction.y * j)) == listToCompare[i].PositionY))
                    {
                        enemieToDistance = true;
                        auxDistance = j;
                        listSoldierToUpdateLive.Add(listToCompare[i]);
                        //auxEnemy = i;
                        break;

                    }
                } 
                
            }
            if (enemieToDistance == true) { break; }
        }
        if(enemieToDistance==false)
        {
            auxDistance = maxDistanceAtt;
        }
        for (int j = minDistanceAtt; j <= auxDistance; j++)
        {
            for (int i = 0; i < FindObjects.listIntransitables.Count; i++)
            {
                
                if (((positionX - (direction.x * j)) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x) && ((positionY - (direction.y * j)) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y))
                {
                    
                    if (typeSoldier == "Soldier" && FindObjects.listIntransitables[i].GetComponent<SelectMaterial>() != null)
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().Destroyable == true)
                        {
                            //Debug.Log("ATAQUE ESTOCADA A OBJETO");
                            listObjectToUpdateLive.Add(FindObjects.listIntransitables[i]);
                            listSoldierToUpdateLive.Clear();
                            return true;
                        }
                    }
                    else
                    {
                        listSoldierToUpdateLive.Clear();
                        return false;
                    }
                }
            }
        }

        for (int j = minDistanceAtt; j <= auxDistance; j++)
        {
            for (int i = 0; i < listOfAliados.Count; i++)
            {
                if (listOfAliados[i].Id != 0)
                {
                    if (((positionX - (direction.x * j)) == listOfAliados[i].PositionX) && ((positionY - (direction.y * j)) == listOfAliados[i].PositionY))
                    {
                        listSoldierToUpdateLive.Clear();
                        return false;
                    }
                }
            }
        }
        //if (typeSoldier == "Soldier" && enemieToDistance == true)
        if(enemieToDistance == true)
        {
            //Debug.Log("ATAQUE ESTOCADA");
            //listToCompare[auxEnemy].Life = (listToCompare[auxEnemy].Life - damage);
            //Debug.Log(Soldier.listSoldiers[j].Life);
            //listSoldierToUpdateLive.Add(listToCompare[auxEnemy]);
            return true;
        }
        
        return false;
    }

    public bool CheckAttackBarrido(float positionX, float positionY, Vector2 direction,int minDistanceAtt, int maxDistanceAtt, string typeSoldier)
    {
        bool enemieToDistance = false;
        bool objectToDistance = false;
        listSoldierToUpdateLive.Clear();
        listObjectToUpdateLive.Clear();
        //int[] auxEnemy = new int[Soldier.listEnemies.Count];
        //int[] auxObject = new int[FindObjects.listIntransitables.Count];
        //int n = 0;

        if (typeSoldier == "Soldier")
        {
            listToCompare = Soldier.listEnemies;
        }
        else
        {
            listToCompare = Soldier.listSoldiers;
        }
        for (int i = 0; i < listToCompare.Count; i++)
        {
            //Debug.Log("PositionSoldierX:" + (positionX - (direction.x * minDistanceAtack)) + "PositionSoldierY:" + (positionY - (direction.y * maxDistanceAtack)));
            //Debug.Log("PositionSoldierX:" + (positionX - (direction.x * minDistanceAtack)) + "PositionSoldierY:" + (positionY + (direction.y * maxDistanceAtack)));
            //Debug.Log("PositionEnemyX:" + Soldier.listEnemies[i].getPositionX() + "PositionEnemyY:" + Soldier.listEnemies[i].getPositionY());
            if (listToCompare[i].Id != 0)
            {
                if (direction.y == 0)
                {

                    if ((positionX - (direction.x * minDistanceAtack) == listToCompare[i].PositionX) && (positionY - (direction.y * minDistanceAtack) == listToCompare[i].PositionY))
                    {
                        listSoldierToUpdateLive.Add(listToCompare[i]);
                        enemieToDistance = true;
                    }
                    if ((positionX - (direction.x * minDistanceAtack) == listToCompare[i].PositionX) && (positionY - minDistanceAtack == listToCompare[i].PositionY))
                    {
                        listSoldierToUpdateLive.Add(listToCompare[i]);
                        enemieToDistance = true;
                    }
                    if ((positionX - (direction.x * minDistanceAtack) == listToCompare[i].PositionX) && (positionY + minDistanceAtack == listToCompare[i].PositionY))
                    {
                        listSoldierToUpdateLive.Add(listToCompare[i]);
                        enemieToDistance = true;
                    }
                }
                else
                {
                    if ((positionX - (direction.x * minDistanceAtack) == listToCompare[i].PositionX) && ((positionY - (direction.y * minDistanceAtack)) == listToCompare[i].PositionY))
                    {
                        listSoldierToUpdateLive.Add(listToCompare[i]);
                        enemieToDistance = true;
                    }
                    if ((positionX - minDistanceAtack == listToCompare[i].PositionX) && ((positionY - (direction.y * minDistanceAtack)) == listToCompare[i].PositionY))
                    {
                        listSoldierToUpdateLive.Add(listToCompare[i]);
                        enemieToDistance = true;
                    }
                    if ((positionX + minDistanceAtack == listToCompare[i].PositionX) && ((positionY - (direction.y * minDistanceAtack)) == listToCompare[i].PositionY))
                    {
                        listSoldierToUpdateLive.Add(listToCompare[i]);
                        enemieToDistance = true;
                    }
                }

            }
                
        }
        //n = 0;
        for (int i = 0; i < FindObjects.listIntransitables.Count; i++)
        {
            //Debug.Log("PositionEnemyX:"+Soldier.listEnemies[i].getPositionX()+"PositionEnemyY:"+ Soldier.listEnemies[i].getPositionY());
            if (direction.y == 0)
            {
                if((positionX - (direction.x * minDistanceAtack) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x) && (positionY - (direction.y * minDistanceAtack) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y))
                {
                    if (typeSoldier == "Soldier" && FindObjects.listIntransitables[i].GetComponent<SelectMaterial>() != null)
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().Destroyable == true)
                        {
                            //Debug.Log("ATAQUE BARRIDO A OBJETO");
                            listObjectToUpdateLive.Add(FindObjects.listIntransitables[i]);
                            objectToDistance = true;
                        }
                    }
                }
                if((positionX - (direction.x * minDistanceAtack) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x) && (positionY - minDistanceAtack == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y))
                {
                    if (typeSoldier == "Soldier" && FindObjects.listIntransitables[i].GetComponent<SelectMaterial>() != null)
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().Destroyable == true)
                        {
                            //Debug.Log("ATAQUE BARRIDO A OBJETO");
                            listObjectToUpdateLive.Add(FindObjects.listIntransitables[i]);
                            objectToDistance = true;
                        }
                    }
                }
                if((positionX - (direction.x * minDistanceAtack) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x) && (positionY + minDistanceAtack == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y))
                {
                    if (typeSoldier == "Soldier" && FindObjects.listIntransitables[i].GetComponent<SelectMaterial>() != null)
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().Destroyable == true)
                        {
                           // Debug.Log("ATAQUE BARRIDO A OBJETO");
                            listObjectToUpdateLive.Add(FindObjects.listIntransitables[i]);
                            objectToDistance = true;
                        }
                    }
                }

            }
            else
            {
                if ((positionX - (direction.x * minDistanceAtack) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x) && (positionY - (direction.y * minDistanceAtack) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y))
                {
                    if (typeSoldier == "Soldier" && FindObjects.listIntransitables[i].GetComponent<SelectMaterial>() != null)
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().Destroyable == true)
                        {
                            //Debug.Log("ATAQUE BARRIDO A OBJETO");
                            listObjectToUpdateLive.Add(FindObjects.listIntransitables[i]);
                            objectToDistance = true;
                        }
                    }
                }
                if((positionX - minDistanceAtack == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x) && (positionY - (direction.y * minDistanceAtack) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y))
                {
                    if (typeSoldier == "Soldier" && FindObjects.listIntransitables[i].GetComponent<SelectMaterial>() != null)
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().Destroyable == true)
                        {
                            //Debug.Log("ATAQUE BARRIDO A OBJETO");
                            listObjectToUpdateLive.Add(FindObjects.listIntransitables[i]);
                            objectToDistance = true;
                        }
                    }
                }
                if((positionX + minDistanceAtack == FindObjects.listIntransitables[i].GetComponent<Transform>().position.x) && (positionY - (direction.y * minDistanceAtack) == FindObjects.listIntransitables[i].GetComponent<Transform>().position.y))
                {
                    if (typeSoldier == "Soldier" && FindObjects.listIntransitables[i].GetComponent<SelectMaterial>() != null)
                    {
                        if (FindObjects.listIntransitables[i].GetComponent<SelectMaterial>().Destroyable == true)
                        {
                           // Debug.Log("ATAQUE BARRIDO A OBJETO");
                            listObjectToUpdateLive.Add(FindObjects.listIntransitables[i]);
                            objectToDistance = true;
                        }
                    }
                }
            }
        }

        if ((objectToDistance == true || enemieToDistance == true)&& typeSoldier=="Soldier") {
            return true;
        }
        if (enemieToDistance == true && typeSoldier == "Enemy")
        {
            return true;
        }
        return false;
    }

}



