﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

[CreateAssetMenu(fileName = "NewDataBaseScene", menuName = "createDataBaseScene")]
public class DataBaseScenes : ScriptableObject
{
    [Tooltip("Variable que permite añadir escenas")]
    //public ScenesStruct[] sceneStract;
    [SerializeField]
    public Object[] sceneObj;

    //[System.Serializable]
    //public struct ScenesStruct
    //{
    //    [Tooltip("Variable que indica el nombre de la escena, debe corresponderse con el nombre de una escena guardada")]
    //    public string nameScene;
    //}


}
