﻿using UnityEngine;

[CreateAssetMenu(fileName = "NewFormation", menuName = "createFormation")]
public class DataBaseFormation : PersistentScriptableObject
{
    public int width;
    public int height;
    public dataBaseSoldiers[] typeSoldier;

}
