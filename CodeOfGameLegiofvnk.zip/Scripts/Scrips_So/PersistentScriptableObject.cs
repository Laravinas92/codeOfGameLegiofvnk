﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public abstract class PersistentScriptableObject : ScriptableObject
{
    public void Save(String savePath)
    {
        string saveData = JsonUtility.ToJson(this,true);
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(string.Concat(Application.persistentDataPath,savePath));
        bf.Serialize(file, saveData);
        file.Close();
    }

    public virtual void Load(String savePath)
    {
        if (File.Exists(string.Concat(Application.persistentDataPath, savePath))) {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(string.Concat(Application.persistentDataPath, savePath), FileMode.Open);
            JsonUtility.FromJsonOverwrite(bf.Deserialize(file).ToString(),this);
            file.Close();


        }
    }

    private string GetPath(string fileName=null)
    {
        string fullFileName = string.IsNullOrEmpty(fileName) ? name : fileName;
        string retorString =string.Format("{0}/{1}.dat", Application.persistentDataPath, fullFileName);
        return retorString;
    }
}
