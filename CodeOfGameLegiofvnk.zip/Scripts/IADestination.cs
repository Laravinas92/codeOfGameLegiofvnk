﻿using Pathfinding;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IADestination : MonoBehaviour
{
    private FindEnemies findEnemiesSC;
    //private EnemyIA enemyIA;
    private List<Vector3> actualVectorsNodos = new List<Vector3>();
    private Soldier bestSoldierToApprox;
    private List<Vector3> bestVectorsNodos = new List<Vector3>();
    private int bestLenghtNodes = 0;
    private Vector3 nextPointToMove = new Vector3(0, 0, 0);
    private Soldier[] randomSoldier = new Soldier[2];
    private bool noMove=false;
    //public delegate void EnemyIA(Vector3 positionSoldier,Vector3 positionEnemy);
    //public static event EnemyIA eventEnemyIA;

    private void OnEnable()
    {
        EventActionsController.eventIADestination += CheckPath;
    }

    private void OnDisable()
    {
        EventActionsController.eventIADestination -= CheckPath;
    }

    // Start is called before the first frame update
    void Start()
    {
        //actionsControllerSC = GameObject.FindGameObjectWithTag("Actions");
        findEnemiesSC = FindObjectOfType<FindEnemies>();
    }
    private void CheckPath(GameObject enemyGO,EnemyIA enemyIA)
    {
        actualVectorsNodos.Clear();
        bestVectorsNodos.Clear();
        //GameObject enemyGO = GameObject.Find("QuadEnemy_" + enemy.Id);
        //if (enemyGO != null)
        //{
        //    enemyIA = enemyGO.GetComponent<EnemyIA>();
        //}
        //else
        //{
        //    Debug.Log("No se encuentra al enenmigo");
        //}
        for (int i = 0; i < Soldier.listSoldiers.Count; i++)
        {
            if (Soldier.listSoldiers[i].Id!=0)
            {
                actualVectorsNodos = new List<Vector3>(enemyIA.CheckBestSoldierToApprox(new Vector3(Soldier.listSoldiers[i].PositionX, Soldier.listSoldiers[i].PositionY, 0.99f), enemyGO));

                //actualVectorsNodos = new List<Vector3>(enemyIA.CheckBestSoldierToApprox(new Vector3(Soldier.listSoldiers[i].PositionX, Soldier.listSoldiers[i].PositionY,0.99f), new Vector3(enemy.PositionX, enemy.PositionY, 0.99f)));
                if (bestVectorsNodos.Count==0)
                {
                    bestVectorsNodos = new List<Vector3>(actualVectorsNodos);
                    bestLenghtNodes = bestVectorsNodos.Count;
                    bestSoldierToApprox = Soldier.listSoldiers[i];
                }
                else
                {
                    if (actualVectorsNodos.Count <= bestLenghtNodes)
                    {
                        if (actualVectorsNodos.Count == bestLenghtNodes)
                        {
                            if (Soldier.listSoldiers[i].Life <= bestSoldierToApprox.Life)//Comprobar vida y fuerza
                            {
                                //Debug.Log(" " + Soldier.listSoldiers[i].SoldierGO.name+" " + Soldier.listSoldiers[i].Life+" "+bestSoldierToApprox.SoldierGO.name +" " + bestSoldierToApprox.Life);
                                if (Soldier.listSoldiers[i].Life == bestSoldierToApprox.Life)
                                {
                                    if (Soldier.listSoldiers[i].Strength >= bestSoldierToApprox.Strength)
                                    {
                                        if (Soldier.listSoldiers[i].Strength == bestSoldierToApprox.Strength)
                                        {
                                            randomSoldier[0] = bestSoldierToApprox;
                                            randomSoldier[1] = Soldier.listSoldiers[i];
                                            bestSoldierToApprox = randomSoldier[UnityEngine.Random.Range(0, randomSoldier.Length)];
                                            if (bestSoldierToApprox.Id== Soldier.listSoldiers[i].Id)
                                            {
                                                bestVectorsNodos = new List<Vector3>(actualVectorsNodos);
                                                bestLenghtNodes = bestVectorsNodos.Count;
                                                bestSoldierToApprox = Soldier.listSoldiers[i];
                                            }
                                        }
                                        else
                                        {
                                            bestVectorsNodos = new List<Vector3>(actualVectorsNodos);
                                            bestLenghtNodes = bestVectorsNodos.Count;
                                            bestSoldierToApprox = Soldier.listSoldiers[i];
                                        }
                                    }
                                }
                                else
                                {
                                    bestVectorsNodos = new List<Vector3>(actualVectorsNodos);
                                    bestLenghtNodes = bestVectorsNodos.Count;
                                    bestSoldierToApprox = Soldier.listSoldiers[i];
                                }
                            }

                        }
                        else
                        {
                            bestVectorsNodos = new List<Vector3>(actualVectorsNodos);
                            bestLenghtNodes = bestVectorsNodos.Count;
                            bestSoldierToApprox = Soldier.listSoldiers[i];
                        }
                    }
                }
            }
            
        }
        //for (int p = 0; p < bestVectorsNodos.Count; p++)
        //{
        //    Debug.Log("ActualVector: " + bestVectorsNodos[p]);
        //}
        if (bestVectorsNodos.Count > 2)
        {
            //Debug.Log("Name Enemigo: "+ enemyGO.name + "Numero de Vectores: "+actualVectorsNodos.Count);

            nextPointToMove = bestVectorsNodos[1];
            noMove = false;
            for (int i = 0; i < Soldier.listEnemies.Count; i++)
            {
                if (Soldier.listEnemies[i].PositionX== nextPointToMove.x && Soldier.listEnemies[i].PositionY == nextPointToMove.y)
                {
                    //Debug.Log("NextPoint: " + nextPointToMove + "SoldierPosition: " + Soldier.listEnemies[i].PositionX + "_" + Soldier.listEnemies[i].PositionY);
                    noMove = true;
                    break;
                }
            
            }
            if (noMove ==false)
            {
                findEnemiesSC.UpdatePostitionEnemy(enemyGO, new Vector3(nextPointToMove.x, nextPointToMove.y, 0.99f));
            }
                
        }

    }
}
