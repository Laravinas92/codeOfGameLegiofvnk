﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Soldier 
{
    public static List<Soldier> listSoldiers = new List<Soldier>();
    public static List<Soldier> listEnemies = new List<Soldier>();
    public static List<Soldier> listSoldiersTemp = new List<Soldier>();

    public float Life { get; set; }
    public float LifeDB { get; set; }
    public string TypeSoldier { get; set; }
    public int Strength { get; set; }
    public dataBaseAttacks TypeAttacks { get; set; }
    public string[] SpecialAbility { get; set; }
    public GameObject IconUnit { get; set; }
    public int Id { get; set; }
    public float PositionX { get; set; }
    public float PositionY { get; set; }
    public GameObject SoldierGO { get; set; }
    public Material Material { get; set; }


    public Soldier() { }

    public Soldier(float life,float lifeDB,string typeSoldier, int strength, dataBaseAttacks typeAttacks, string[] specialAbility, GameObject iconUnit, float positionX, float positionY, int id,GameObject soldierGO,Material material)
    {
        Life = life;
        TypeSoldier = typeSoldier;
        Strength = strength;
        TypeAttacks = typeAttacks;
        SpecialAbility = specialAbility;
        IconUnit = iconUnit;
        PositionX = positionX;
        PositionY = positionY;
        Id = id;
        SoldierGO = soldierGO;
        LifeDB = lifeDB;
        Material = material;

    }


    //public float getLife()
    //{
    //    return Life;
    //}
    //public void setLife(float life)
    //{
    //    this.Life = life;
    //}

    //public string getTypeSoldier()
    //{
    //    return TypeSoldier;
    //}
    //public void setTypeSoldier(string typeSoldier)
    //{
    //    this.TypeSoldier = typeSoldier;
    //}
    //public int getStrength()
    //{
    //    return Strength;
    //}
    //public void setStrength(int strength)
    //{
    //    this.Strength = strength;
    //}
    //public dataBaseAttacks[] getTypeAttacks()
    //{
    //    return TypeAttacks;
    //}
    //public void setTypeAttacks(dataBaseAttacks[] typeAttacks)
    //{
    //    this.TypeAttacks = typeAttacks;
    //}
    //public string[] getSpecialAbility()
    //{
    //    return SpecialAbility;
    //}
    //public void setSpecialAbility(string[] specialAbility)
    //{
    //    this.SpecialAbility = specialAbility;
    //}
    //public Sprite getIconUnit()
    //{
    //    return IconUnit;
    //}
    //public void setIconUnit(Sprite iconUnit)
    //{
    //    this.IconUnit = iconUnit;
    //}
    //public GameObject getIconUnit_2()
    //{
    //    return IconUnit_2;
    //}
    //public void setIconUnit_2(GameObject iconUnit_2)
    //{
    //    this.IconUnit_2 = iconUnit_2;
    //}
    //public int getId()
    //{
    //    return Id;
    //}
    //public void setId(int id)
    //{
    //    this.Id = id;
    //}
    //public float getPositionX()
    //{
    //    return PositionX;
    //}
    //public void setPositionX(float positionX)
    //{
    //    this.PositionX = positionX;
    //}
    //public float getPositionY()
    //{
    //    return PositionY;
    //}
    //public void setPositionY(float positionY)
    //{
    //    this.PositionY = positionY;
    //}


    //public void UpDatePositionSoldiers(string letter, Vector2 direction)
    //{
    //    if (!this.CompareTag("Soldier"))
    //    {
    //        if (letter == "w")
    //        {
    //            formationGO.GetComponent<Transform>().position -= new Vector3(0, -1, 0);

    //        }
    //        else
    //        {
    //            if (letter == "s")
    //            {
    //                formationGO.GetComponent<Transform>().position -= new Vector3(0, 1, 0);
    //            }
    //            else
    //            {
    //                if (letter == "a")
    //                {
    //                    formationGO.GetComponent<Transform>().position -= new Vector3(1, 0, 0);
    //                }

    //                else
    //                {
    //                    if (letter == "d")
    //                    {
    //                        formationGO.GetComponent<Transform>().position -= new Vector3(-1, 0, 0);
    //                    }

    //                }
    //            }

    //        }
    //    }
        


        
    //}

}
