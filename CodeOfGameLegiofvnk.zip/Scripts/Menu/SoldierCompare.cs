﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoldierCompare : IComparer<Soldier> 
{
    public int Compare(Soldier x, Soldier y)
    {

        if (x.PositionY < y.PositionY)
        {
            return 1;
        }
        else
        {
            if (x.PositionY > y.PositionY)
            {
                return -1;
            }
            else
            {
                if (x.PositionY == y.PositionY)
                {
                    if (x.PositionX < y.PositionX)
                    {
                        return -1;
                    }
                    else
                    {
                        if (x.PositionX > y.PositionX)
                        {
                            return 1;
                        }

                    }
                }
            }
        }
        return 0;
    }
}
