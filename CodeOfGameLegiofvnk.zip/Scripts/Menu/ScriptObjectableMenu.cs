﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Menu", menuName = "NewMenu")]
public class ScriptObjectableMenu : ScriptableObject
{
    public SectionMenu[] sectionMenu;
}

[System.Serializable]
public struct SectionMenu
{
    public string nameSoldier;
    [TextArea(3, 50)]//Para agrandar el espacio del texto minimo 3 maximo 10
    public string textDescription;
    public Sprite SpriteSoldier;
    public dataBaseSoldiers dataBaseSoldier;
}