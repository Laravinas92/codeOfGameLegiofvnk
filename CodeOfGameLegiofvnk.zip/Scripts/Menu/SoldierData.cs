﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class SoldierSave
{
    public string typeSoldier;
    public float positionX;
    public float positionY;

    public SoldierSave()
    {
        this.typeSoldier = "";
        this.positionX = 0;
        this.positionY = 0;
    }

    public SoldierSave(string typeSoldier, float positionX, float positionY)
    {
        this.typeSoldier = typeSoldier;
        this.positionX = positionX;
        this.positionY = positionY;
    }


    public string getTypeSoldier()
    {
        return this.typeSoldier;
    }
    public void setTypeSoldier(string typeSoldier)
    {
        this.typeSoldier = typeSoldier;
    }

    public float getPositionX()
    {
        return this.positionX;
    }
    public void setPositionX(float positionX)
    {
        this.positionX = positionX;
    }
    public float getPositionY()
    {
        return this.positionY;
    }
    public void setPositionY(float positionY)
    {
        this.positionY = positionY;
    }
}


public class SoldierData : MonoBehaviour
{
    public static SoldierSave GenerateData(SoldierSave soldierSave)
    {
        return new SoldierSave(soldierSave.getTypeSoldier(), soldierSave.getPositionX(), soldierSave.getPositionY());
    }
}
