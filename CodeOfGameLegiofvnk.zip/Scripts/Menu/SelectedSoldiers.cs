﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SelectedSoldiers : MonoBehaviour
{
    [Tooltip("Arrastrar el asset creado con el tipo de soldado")]
    private dataBaseSoldiers dataBaseSoldier;
    private GameObject panelSelectedSoldier;
    public ScriptObjectableMenu menu;
    public GameObject prefabImage;
    //public static List<SoldierSave> listSoldiers = new List<SoldierSave>();
    public static List<string> listSoldiers = new List<string>();
    //public static List<Soldier> listBorrar = new List<Soldier>();
    public static int instanceNumber = 1;
    public static int rows = 0;
    public static int columns = 0;
    //private Vector3 unitPosition = new Vector3(1, 1, 0.99f);
    public GameObject buttonPlay;
    private GameObject image;
    private bool largeSize = false;
    private float positionY = 0;
    public DataBaseFormation formationDB;
    public GameObject dropdownGO;
    private void Start()
    {
        panelSelectedSoldier = GameObject.Find("PanelSelectedSoldier");
        if (panelSelectedSoldier == null)
        {
            Debug.Log("Error GameObject panelSelectedSoldier no asignado ");
        }
        else {
            if (formationDB.width <= 6 && formationDB.height <= 6)
            {
                panelSelectedSoldier.GetComponent<RectTransform>().sizeDelta = new Vector2(110 * formationDB.width, 110 * formationDB.height);
                if (formationDB.width<5)
                {
                    panelSelectedSoldier.GetComponent<GridLayoutGroup>().padding.top = 8;
                    panelSelectedSoldier.GetComponent<GridLayoutGroup>().padding.left = 8;
                }
                else
                {
                        panelSelectedSoldier.GetComponent<GridLayoutGroup>().padding.left = 15;
                        panelSelectedSoldier.GetComponent<GridLayoutGroup>().padding.top = 15;
                }
            }
            else
            {
                panelSelectedSoldier.GetComponent<RectTransform>().sizeDelta = new Vector2(85 * formationDB.width, 85 * formationDB.height);
                panelSelectedSoldier.GetComponent<GridLayoutGroup>().spacing = new Vector2(12,12);
                panelSelectedSoldier.GetComponent<GridLayoutGroup>().cellSize = new Vector2(70,70);
                panelSelectedSoldier.GetComponent<GridLayoutGroup>().padding.left = 15;
                panelSelectedSoldier.GetComponent<GridLayoutGroup>().padding.top = 15;
                largeSize = true;
            }
        }

        
        for (int i = 0; i < (formationDB.width * formationDB.height); i++)
        {
            if (prefabImage != null)
            {
                image = Instantiate(prefabImage);
                if (largeSize == true)
                {
                    image.GetComponent<RectTransform>().localScale = new Vector3(0.85f, 0.85f, 0.85f);
                    image.transform.GetChild(0).GetComponent<RectTransform>().localScale = new Vector3(0.85f, 0.85f, 0.85f);
                }
                
                image.transform.SetParent(panelSelectedSoldier.transform);
                image.name = "Image" + (i+1);
                //panelSelectedSoldier.transform.GetChild(instanceNumber - 1).gameObject.GetComponent<Image>().sprite = dataBaseSoldier.spriteUnit;
            }
            else
            {
                Debug.Log("Objeto prefabImage no asignado en el script SelectSoldier");
            }
        }

        CalculatePositionButtonPlay();

        if (buttonPlay != null)
        {
            buttonPlay.SetActive(false);
            buttonPlay.GetComponent<Transform>().position = new Vector3(buttonPlay.GetComponent<Transform>().position.x + 120, positionY - 40, buttonPlay.GetComponent<Transform>().position.z);
        }
        else
        {
            Debug.Log("Boton play no asignado");
        }

        if (dropdownGO != null)
        {
            dropdownGO.SetActive(false);
            dropdownGO.GetComponent<Transform>().position = new Vector3(dropdownGO.GetComponent<Transform>().position.x + 250, positionY - 40, dropdownGO.GetComponent<Transform>().position.z);
        }
        else
        {
            Debug.Log("Objecto DropDown no asignado en el inspector, script SelectedSoldiers");
        }


    }
    public void createSoldier()
    {

        if (instanceNumber < (formationDB.width*formationDB.height+1))
        {
            //positionSoldier();
            SectionMenu sectionMenu = menu.sectionMenu[Menu.index];
            dataBaseSoldier = sectionMenu.dataBaseSoldier;

            if (formationDB.height*formationDB.width >= instanceNumber)
            {
                panelSelectedSoldier.transform.GetChild(instanceNumber - 1).transform.GetChild(0).gameObject.GetComponent<Image>().sprite = dataBaseSoldier.spriteUnit;

                //if (prefabImage!=null)
                //{
                    
                //    image = Instantiate(prefabImage);
                    
                //    image.transform.SetParent(panelSelectedSoldier.transform);
                //    image.GetComponent<Image>().transform.GetChild(0).GetComponent<Image>().sprite = dataBaseSoldier.spriteUnit;
                //    image.name = "Image" + instanceNumber;
                //    //panelSelectedSoldier.transform.GetChild(instanceNumber - 1).gameObject.GetComponent<Image>().sprite = dataBaseSoldier.spriteUnit;
                //}
                //else
                //{
                //    Debug.Log("Objeto prefabImage no asignado en el script SelectSoldier");
                //}
                //image.GetComponent<Image>().transform.GetChild(0).GetComponent<Image>().sprite = dataBaseSoldier.spriteUnit;

            }
            listSoldiers.Add(dataBaseSoldier.typeSoldier);
            if (formationDB.typeSoldier.Length>=instanceNumber)
            {
                formationDB.typeSoldier[instanceNumber - 1] = dataBaseSoldier;
            }
            else
            {
                Debug.Log("Comprobar que las dimensiones de la formacion corresponden con el numero de soldados");
            }
            
            instanceNumber++;

            columns++;
            if (columns > (formationDB.width-1))
            {
                columns = 0;
                rows++;
            }

        }
    }


    //public void positionSoldier()
    //{
    //    SectionMenu sectionMenu = menu.sectionMenu[Menu.index];
    //    dataBaseSoldier = sectionMenu.dataBaseSoldier;
       
    //    if (countChilds>= instanceNumber) {
    //        panelSelectedSoldier.transform.GetChild(instanceNumber-1).transform.GetChild(0).gameObject.GetComponent<Image>().sprite = dataBaseSoldier.spriteUnit;
    //    }
    //    //dataBaseSoldier.positionX = unitPosition.x + columns;
    //    //dataBaseSoldier.positionY = unitPosition.y - rows;
    //    //listSoldiers.Add(dataBaseSoldiers.CreateInstance(dataBaseSoldier.live, dataBaseSoldier.typeAttacks, dataBaseSoldier.iconUnit, dataBaseSoldier.positionX, dataBaseSoldier.positionY, 1));
    //    //listSoldiers.Add(new SoldierSave(dataBaseSoldier.typeSoldier,unitPosition.x,unitPosition.y));
    //    listSoldiers.Add(dataBaseSoldier.typeSoldier);
        
    //    formationDB.typeSoldier[instanceNumber-1] = dataBaseSoldier.typeSoldier;
    //    instanceNumber++;

    //    columns++;
    //    if (columns > 2)
    //    {
    //        columns = 0;
    //        rows++;
    //    } 
    //}

    private void Update()
    {

        if (buttonPlay != null && listSoldiers.Count==(formationDB.height*formationDB.width) && !buttonPlay.activeInHierarchy)
        {
            buttonPlay.SetActive(true);
        }
        else
        {
            if (buttonPlay != null && buttonPlay.activeInHierarchy && listSoldiers.Count != (formationDB.height * formationDB.width))
            {
                buttonPlay.SetActive(false);
            }
            
        }
        if (dropdownGO!= null && listSoldiers.Count == (formationDB.height * formationDB.width) && !dropdownGO.activeInHierarchy)
        {
            dropdownGO.SetActive(true);
        }
        else
        {
            if (dropdownGO != null && dropdownGO.activeInHierarchy && listSoldiers.Count != (formationDB.height * formationDB.width))
            {
                dropdownGO.SetActive(false);
            }

        }



    }

    public void CalculatePositionButtonPlay()
    {
        Vector3[] corners = new Vector3[4];
        panelSelectedSoldier.GetComponent<RectTransform>().GetWorldCorners(corners);
        for (int i = 0; i < corners.Length; i++)
        {
            if (i == 0)
            {
                positionY = corners[i].y;
            }
            else
            {
                if (positionY > corners[i].y)
                {
                    positionY = corners[i].y;
                }
            }
        }

    }   
}

