﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;
using System;

public class Menu : MonoBehaviour
{
    //Variables incluidas desde Unity
    public GameObject Image;
    public GameObject description;
    public GameObject nameText;
    public GameObject buttonNext;
    public GameObject buttonPrevious;
    public ScriptObjectableMenu menu;
    public DataBaseScenes scenes;
    public TMP_Dropdown dropdown;
    public GameObject panelGO;
    private List<string> listNameScenes = new List<string>();


    //Variables utilizadas en el script
    public static int index = 0;

    // Start is called before the first frame update
    private void Start()
    {
        //Se imprime la primera página en pantalla con el primer elemento de la base de datos
        GenerateBoxOptionsSceneToLoad();
        UpdateInformation();
        
    }

    public void GenerateBoxOptionsSceneToLoad()
    {
        listNameScenes.Clear();
        listNameScenes.Add("Selecciona Partida");
        if (scenes!=null){
            for (int i = 0; i < scenes.sceneObj.Length; i++)
            {
                listNameScenes.Add(scenes.sceneObj[i].name);

            }
        }
        else{
            Debug.Log("No se ha asignado la base de Datos de escenas en el inspector, script Menu");
        }

        if (dropdown!=null){
            dropdown.AddOptions(listNameScenes);
        }
        else{
            Debug.Log("No se ha asignado el objeto Dropdown en el inspector, script Menu");
        
        }
    }

    public void Update()
    {
        //Activar o desactivar los botones, anterior y siguiente, si existe más personajes de los que informar o no
        if (menu.sectionMenu.Length - 1 == index)
        {
            buttonNext.SetActive(false);
        }
        else
        {
            buttonNext.SetActive(true);
        }
        if (index == 0)
        {
            buttonPrevious.SetActive(false);
        }
        else
        {
            buttonPrevious.SetActive(true);
        }
    }
    //Selecciona la posicion de la siguiente página
    public void NextPage()
    {
        index++;
    }
    //Selecciona la posicion de la  página anterior
    public void PreviousPage()
    {
        if (index > 0)
            index--;
    }
    //Actualiza la informacion en pantalla correspondiente a la posición de la base de datos
    public void UpdateInformation()
    {
        SectionMenu sectionMenu = menu.sectionMenu[index];
        if (Image != null)
        {
            Image.GetComponent<Image>().sprite = sectionMenu.dataBaseSoldier.spriteUnit;
        }
        else
        {
            Debug.Log("Objeto image no asignado en Menu");
        }

        if (nameText != null)
        {
            nameText.GetComponent<TextMeshProUGUI>().text = sectionMenu.nameSoldier;
            nameText.GetComponent<TextMeshProUGUI>().fontStyle = FontStyles.Bold;

        }
        if (description != null)
        {
            description.GetComponent<TextMeshProUGUI>().text = sectionMenu.textDescription;

        }

        
    }


    public void LoadScene() {

        if (dropdown.GetComponentInChildren<TextMeshProUGUI>().text != listNameScenes[0])
        {
            //Debug.Log(dropdown.GetComponentInChildren<TextMeshProUGUI>().text);
            SceneManager.LoadScene(dropdown.GetComponentInChildren<TextMeshProUGUI>().text);
        }
        
    }

    public void Reset()
    {
        if (panelGO!=null)
        {
            for (int i=0;i< panelGO.transform.childCount;i++)
            {
                panelGO.transform.GetChild(i).gameObject.transform.GetChild(0).gameObject.GetComponent<Image>().sprite = null;
                //panelGO.transform.GetChild(i).gameObject.GetComponent<Image>().sprite = null;
                SelectedSoldiers.columns = 0;
                SelectedSoldiers.rows = 0;
                SelectedSoldiers.instanceNumber = 1;
                SelectedSoldiers.listSoldiers.Clear();
            }
            

        }
        else
        {
            Debug.Log("No se encuentra panelGO en el script Menu");
        }
    }
}
