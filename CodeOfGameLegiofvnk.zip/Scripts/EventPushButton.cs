﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventPushButton : MonoBehaviour
{

    public delegate void PushBotton(String letter,Vector2 direction,float timePushBotton);
    public static event PushBotton eventPushBotton;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    

    // Update is called once per frame
    void Update()
    {
        CheckButtonPush();
    }

    private void CheckButtonPush()
    {
        //if (Input.GetKeyDown(KeyCode.W))
        //{
        //    eventPushBotton("w",Time.time);
        //}
        //else
        //{
        //    if (Input.GetKeyDown(KeyCode.A))
        //    {
        //        eventPushBotton("a", Time.time);
        //    }
        //    else
        //    {
        //        if (Input.GetKeyDown(KeyCode.S))
        //        {
        //            eventPushBotton("s", Time.time);
        //        }
        //        else
        //        {
        //            if (Input.GetKeyDown(KeyCode.D))
        //            {
        //                eventPushBotton("d", Time.time);
        //            }
        //        }
        //    }
        //}


        if (Input.GetKeyDown(KeyCode.W))
        {
            eventPushBotton("w", new Vector2(0, -1), Time.time);
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            eventPushBotton("a", new Vector2(1, 0), Time.time);
        }
        if (Input.GetKeyDown(KeyCode.S))
        {
            eventPushBotton("s", new Vector2(0, 1), Time.time);
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            eventPushBotton("d", new Vector2(-1, 0), Time.time);
        }
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            eventPushBotton("f1", new Vector2(0, 0), Time.time);
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            eventPushBotton("f2", new Vector2(0, 0), Time.time);
        }
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            eventPushBotton("f3", new Vector2(0, 0), Time.time);
        }


    }
}
