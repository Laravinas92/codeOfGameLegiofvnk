﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerFormation : MonoBehaviour
{
    private int[,] matrix;
    private int[,] temp;
    private GameObject soldierActualGO;
    private List<int> listActualIds = new List<int>();
    private List<int> listTempsIds = new List<int>();
    private List<int> listUpdateTempsIds = new List<int>();
    private List<Soldier> listUpdateSoliersTemp = new List<Soldier>();
    //private List<Soldier> Soldier.listSoldiersTemp = new List<Soldier>();
    //private int newWidht = 0;
    //private int newHeight = 0;
    //private int tempNewWidht = 0;
    //private int tempNewHeight = 0;

    private void OnEnable()
    {
        EventActionsController.eventControllerFormation += WhatToDoOnChangeFormation;
        
    }

    private void WhatToDoOnChangeFormation()
    {
        ReadListSoldier();

        switch (EventActionsController.ChangeFormationCase)
        {
            case 1:
                if (EventActionsController.newHeight != 1)
                { 
                    CheckIfRowAllZeros();
                    GenerateMatrix();
                    VerticalMove();
                    CreateListTempSoldiers();
                }
                break;

            case 2:
                if (EventActionsController.newWidht != 1)
                {
                    CheckIfColumnsAllZeros();
                    GenerateMatrix();
                    HorizontalMove();
                    CreateListTempSoldiers();
                }

                break;

            case 3:
                if (Soldier.listSoldiers.Count != 1)
                {
                    CheckIfRowAllZeros();
                    CheckIfColumnsAllZeros();
                    GenerateMatrix();
                    RotateMove();
                }
                break;
            default:
                break;
        }


    }

    private void OnDisable()
    {
        EventActionsController.eventControllerFormation -= WhatToDoOnChangeFormation;
    }



    //private void Start()
    //{
    //    newWidht = GameState.formationWidht;
    //    newHeight = GameState.formationHeight;
    //    //ReadListSoldier();
    //}

    // Update is called once per frame
    //void Update()
    //{
    //    if (Input.GetKeyDown(KeyCode.Alpha1) && newWidht!=1)
    //    {
    //        //ReadListSoldier(listSoldierRotate, listActualIdsRotate);
    //        ReadListSoldier();
            
    //        //CalculateDimension();
    //        //Debug.Log("Se ha pulsado el 1");
    //        if (newHeight!=1)
    //        {
    //            CheckIfRowAllZeros();
    //            GenerateMatrix();
    //            PrintMatrix("INICIO",1);
    //            VerticalMove();
    //            PrintMatrix("CHANGE",1);
    //            //GenerateMatrix(GameState.formationWidht, GameState.formationHeight, 2);
    //            //PrintMatrix("INICIO", GameState.formationWidht, GameState.formationHeight);
    //            //VerticalMove(GameState.formationWidht, GameState.formationHeight, 2);
    //            //PrintMatrix("CHANGE", GameState.formationWidht, GameState.formationHeight);
    //            //ChangePositionSoldiers(2, listActualIdsRotate, listTempsIdsRotate, listSoldierRotate);
    //            //GenerateMatrix(newWidht, newHeight, 1);

    //            //PrintMatrix("INICIO", newWidht, newHeight);
    //            //VerticalMove(newWidht, newHeight, 1);
    //            //PrintMatrix("CHANGE", newWidht, newHeight);
    //            CreateListTempSoldiers();

    //        }
            
    //    }
    //    else
    //    {
    //        if (Input.GetKeyDown(KeyCode.Alpha2))
    //        {
    //            //Debug.Log("Se ha pulsado el 2");
    //            ReadListSoldier();

    //            if (newWidht != 1)
    //            {
    //                CheckIfColumnsAllZeros();
    //                GenerateMatrix();
    //                PrintMatrix("INICIO",1);
    //                HorizontalMove();
    //                PrintMatrix("CHANGE",1);
    //                //GenerateMatrix(GameState.formationWidht, GameState.formationHeight, 2);
    //                //PrintMatrix("INICIO", GameState.formationWidht, GameState.formationHeight);
    //                //HorizontalMove(GameState.formationWidht, GameState.formationHeight, 2);
    //                //PrintMatrix("CHANGE", GameState.formationWidht, GameState.formationHeight);
    //                //ChangePositionSoldiers(2, listActualIdsRotate, listTempsIdsRotate, listSoldierRotate);
    //                //GenerateMatrix(newWidht, newHeight, 1);
    //                //PrintMatrix("INICIO", newWidht, newHeight);
    //                //HorizontalMove(newWidht,newHeight,1);
    //                //PrintMatrix("CHANGE", newWidht, newHeight);
    //                CreateListTempSoldiers();
    //            }
    //        }
    //        else
    //        {
    //            if (Input.GetKeyDown(KeyCode.Alpha3))
    //            {
    //                if (Soldier.listSoldiers.Count!=1)
    //                {
    //                    //Debug.Log("Se ha pulsado el 3");
    //                    ReadListSoldier();
    //                    CheckIfRowAllZeros();
    //                    CheckIfColumnsAllZeros();
    //                    GenerateMatrix();
    //                    //MatrixTranspose();
    //                    //makeMatrixRotateMove();
    //                    RotateMove();
    //                    //ReadListSoldier(Soldier.listSoldiers, listActualIds);

    //                    //PrintMatrix("INICIO", 1);

    //                    //PrintMatrix("CHANGE_TRANSPOSE", 2);

    //                    //PrintMatrix("CHANGE_ROTATE", 1);

    //                    //PrintMatrix("TRANSPOSE", GameState.formationWidht, GameState.formationHeight);
    //                    //RotateMove2();

    //                    //PrintMatrix("CHANGE_ROTATE", 1);
    //                    //PrintMatrix("CHANGE", GameState.formationWidht, GameState.formationHeight);
    //                    //ChangePositionSoldiers();
    //                    //ChangePositionSoldiers(2, listActualIdsRotate, listTempsIdsRotate, listSoldierRotate);
    //                }

    //            }
    //        }
    //    }
    //}

    private void ReadListSoldier()
    {
        listActualIds.Clear();
        SoldierCompare sc = new SoldierCompare();
        Soldier.listSoldiers.Sort(sc);

        for (int i = 0; i < Soldier.listSoldiers.Count; i++)
        {
            //Debug.Log("Soldado posX" + Soldier.listSoldiers[i].getPositionX() + "Soldado posY" + Soldier.listSoldiers[i].getPositionY());
            string[] str = Soldier.listSoldiers[i].SoldierGO.name.Split(char.Parse("_"));
            int soldierId = Int32.Parse(str[1]);
            listActualIds.Add(soldierId);
            //Debug.Log(Soldier.listSoldiers[i].SoldierGO.name);
        }
    }


    private void CheckIfRowAllZeros()
    {
        int cont = 0;
        int auxNewHeigh = EventActionsController.newHeight;
        Soldier.listSoldiersTemp.Clear();
        listTempsIds.Clear();
        Soldier.listSoldiersTemp = new List<Soldier>(Soldier.listSoldiers);
        listTempsIds = new List<int>(listActualIds);
        //Se empieza a buscar por la primera fila
        for (int i = 0; i < EventActionsController.newHeight; i++)
        {
            for (int j = 0; j < EventActionsController.newWidht; j++)
            {
                if (Soldier.listSoldiers[EventActionsController.newWidht * i + j].Id == 0)
                {
                    //Debug.Log(Soldier.listSoldiers[newWidht * i + j].SoldierGO.name);
                    Soldier.listSoldiersTemp.Remove(Soldier.listSoldiers[(EventActionsController.newWidht * i + j)]);
                    string[] str = Soldier.listSoldiers[(EventActionsController.newWidht * i + j)].SoldierGO.name.Split(char.Parse("_"));
                    int soldierId = Int32.Parse(str[1]);
                    //Debug.Log(listTempsIds.Count + " " + soldierId);
                    listTempsIds.Remove(soldierId);
                    //Debug.Log(listTempsIds.Count);
                    cont++;
                }
            }
            if (cont == EventActionsController.newWidht)
            {
                auxNewHeigh--;
                listUpdateSoliersTemp = new List<Soldier>(Soldier.listSoldiersTemp);
                listUpdateTempsIds = new List<int>(listTempsIds);

            }
            else
            {
                cont = 0;
                break;
            }
            cont = 0;
        }

        if (auxNewHeigh!= EventActionsController.newHeight)
        {
            Soldier.listSoldiers = new List<Soldier>(listUpdateSoliersTemp);
            listActualIds = new List<int>(listUpdateTempsIds);
            listUpdateTempsIds.Clear();
            listUpdateSoliersTemp.Clear();
            EventActionsController.newHeight = auxNewHeigh;
        }
        Soldier.listSoldiersTemp = new List<Soldier>(Soldier.listSoldiers);
        listTempsIds = new List<int>(listActualIds);
        //int n = newHeight - 1;
        //se busca desde la ultima fila 
        if (EventActionsController.newHeight !=1)
        {
            for (int i = EventActionsController.newHeight - 1; i > 0; i--)
            {
                for (int j = 0; j < EventActionsController.newWidht; j++)
                {
                    if (Soldier.listSoldiers[EventActionsController.newWidht * i + j].Id == 0)
                    {
                        //Debug.Log(Soldier.listSoldiers[(newWidht * n + j)].SoldierGO.name);
                        Soldier.listSoldiersTemp.Remove(Soldier.listSoldiers[(EventActionsController.newWidht * i + j)]);
                        string[] str = Soldier.listSoldiers[(EventActionsController.newWidht * i + j)].SoldierGO.name.Split(char.Parse("_"));
                        int soldierId = Int32.Parse(str[1]);
                        //Debug.Log(listTempsIds.Count + " " + soldierId);
                        listTempsIds.Remove(soldierId);
                        //Debug.Log(listTempsIds.Count);
                        cont++;
                    }
                }
                if (cont == EventActionsController.newWidht)
                {
                    auxNewHeigh--;
                    listUpdateSoliersTemp= new List<Soldier>(Soldier.listSoldiersTemp);
                    listUpdateTempsIds = new List<int>(listTempsIds);
                }
                else
                {
                    break;
                }
                cont = 0;
                //n--;
            }
            if (auxNewHeigh != EventActionsController.newHeight)
            {
                Soldier.listSoldiers = new List<Soldier>(listUpdateSoliersTemp);
                listActualIds = new List<int>(listUpdateTempsIds);
                Soldier.listSoldiersTemp.Clear();
                listTempsIds.Clear();
                listUpdateTempsIds.Clear();
                listUpdateSoliersTemp.Clear();
                EventActionsController.newHeight = auxNewHeigh;
            }
        }

        EventActionsController.tempNewHeight = EventActionsController.newHeight;
    }

    private void CheckIfColumnsAllZeros()
    {
        int cont = 0;//lleva la cuenta de zeros por arriba.
        int auxNewWidht = EventActionsController.newWidht;
        Soldier.listSoldiersTemp.Clear();
        listTempsIds.Clear();
        Soldier.listSoldiersTemp = new List<Soldier>(Soldier.listSoldiers);
        listTempsIds = new List<int>(listActualIds);
        for (int i = 0; i < EventActionsController.newWidht; i++)
        {
            for (int j = 0; j < EventActionsController.newHeight; j++)
            {
                //Debug.Log(j);
                //Debug.Log(Soldier.listSoldiers[newWidht * j + i].SoldierGO.name);
                if (Soldier.listSoldiers[(EventActionsController.newWidht * j + i)].Id == 0)
                {
                    //Debug.Log(Soldier.listSoldiers[EventActionsController.newWidht * j + i].SoldierGO.name);
                    Soldier.listSoldiersTemp.Remove(Soldier.listSoldiers[(EventActionsController.newWidht * j + i)]);
                    string[] str = Soldier.listSoldiers[(EventActionsController.newWidht * j + i)].SoldierGO.name.Split(char.Parse("_"));
                    int soldierId = Int32.Parse(str[1]);
                    //Debug.Log(listTempsIds.Count +" "+ soldierId);
                    listTempsIds.Remove(soldierId);
                    //Debug.Log(listTempsIds.Count);
                    cont++;
                }
            }
            if (cont == EventActionsController.newHeight)
            {
                auxNewWidht--;
                listUpdateSoliersTemp = new List<Soldier>(Soldier.listSoldiersTemp);
                listUpdateTempsIds = new List<int>(listTempsIds);
            }
            else
            {
                cont = 0;
                break;
            }
            cont = 0;
        }
        if (auxNewWidht != EventActionsController.newWidht)
        {
            Soldier.listSoldiers = new List<Soldier>(listUpdateSoliersTemp);
            listActualIds = new List<int>(listUpdateTempsIds);
            listUpdateTempsIds.Clear();
            listUpdateSoliersTemp.Clear();
            EventActionsController.newWidht = auxNewWidht;
        }
        Soldier.listSoldiersTemp = new List<Soldier>(Soldier.listSoldiers);
        listTempsIds = new List<int>(listActualIds);
        //Debug.Log(newWidht + " " + newHeight);
        if (auxNewWidht != 1)
        {
            for (int i = EventActionsController.newWidht -1; i >= 0; i--)
            {
                for (int j = EventActionsController.newHeight -1; j >= 0; j--)
                {
                    //Debug.Log(Soldier.listSoldiers[EventActionsController.newWidht * j + i].SoldierGO.name);
                    if (Soldier.listSoldiers[(EventActionsController.newWidht * j + i)].Id == 0)
                    {
                        Soldier.listSoldiersTemp.Remove(Soldier.listSoldiers[(EventActionsController.newWidht * j + i)]);
                        string[] str = Soldier.listSoldiers[(EventActionsController.newWidht * j + i)].SoldierGO.name.Split(char.Parse("_"));
                        int soldierId = Int32.Parse(str[1]);
                        //Debug.Log(listTempsIds.Count +" "+ soldierId);
                        listTempsIds.Remove(soldierId);
                        //Debug.Log(listTempsIds.Count);
                        cont++;
                    }
                }
                if (cont == EventActionsController.newHeight)
                {
                    auxNewWidht--;
                    listUpdateSoliersTemp = new List<Soldier>(Soldier.listSoldiersTemp);
                    listUpdateTempsIds = new List<int>(listTempsIds);
                }
                else
                {
                    break;
                }
                cont = 0;
            }
            if (auxNewWidht != EventActionsController.newWidht)
            {
                Soldier.listSoldiers = new List<Soldier>(listUpdateSoliersTemp);
                listActualIds = new List<int>(listUpdateTempsIds);
                listUpdateTempsIds.Clear();
                listUpdateSoliersTemp.Clear();
                EventActionsController.newWidht = auxNewWidht;
            }
        }

        EventActionsController.tempNewWidht = EventActionsController.newWidht;

        //Debug.Log(EventActionsController.newWidht + " " + EventActionsController.newHeight);

    }

    void GenerateMatrix()
    {
        int n = 0;

        matrix = new int[EventActionsController.newHeight, EventActionsController.newWidht];
        temp = new int[EventActionsController.newHeight, EventActionsController.newWidht];

        //Debug.Log(listActualIds.Count);
        for (int i = 0; i < EventActionsController.newHeight; i++)
        {
            for (int j = 0; j < EventActionsController.newWidht; j++)
            {
                matrix[i, j] = listActualIds[n];
                temp[i, j] = listActualIds[n];
                n++;
            }
        }
    }

    void VerticalMove()
    {
        listTempsIds.Clear();
        int x = 0;

        //La última fila pasa a ser la primera en matrix

        for (int j = 0; j < EventActionsController.newWidht; j++)
        {
            matrix[x, j] = temp[EventActionsController.newHeight - 1, j];
            listTempsIds.Add(matrix[x, j]);
        }
        x++;
        for (int i = 0; i < EventActionsController.newHeight - 1; i++)
        {
            for (int j = 0; j < EventActionsController.newWidht; j++)
            {
                matrix[x, j] = temp[i, j];
                listTempsIds.Add(matrix[x, j]);
            }
            x++;
        }
    }

    private void HorizontalMove()
    {
        for (int i = 0; i < EventActionsController.newHeight; i++)
        {
            for (int j = 1; j < EventActionsController.newWidht; j++)
            {
                matrix[i, j - 1] = temp[i, j];
            }
        }

        //Coloca la primera columna por la izquierda al final
        for (int i = 0; i < EventActionsController.newHeight; i++)
        {
            matrix[i, (EventActionsController.newWidht - 1)] = temp[i, 0];
        }
        UpdateListActualIds();

    }

    private void UpdateListActualIds()
    {
        listTempsIds.Clear();

        for (int i = 0; i < EventActionsController.newHeight; i++)
        {
            for (int j = 0; j < EventActionsController.newWidht; j++)
            {
                //Debug.Log(matrix[i, j]);
                listTempsIds.Add(matrix[i, j]);
            }
        }
    }

    //private void MatrixTranspose()
    //{
    //    int[,] auxTemp = new int[matrix.GetLength(1), matrix.GetLength(0)];
    //    listTempsIds.Clear();

    //    for (int i = 0; i < auxTemp.GetLength(1); i++)
    //    {
    //        for (int j = auxTemp.GetLength(0) - 1; j >= 0; j--)
    //        {
    //            auxTemp[j, i] = matrix[i, j];
    //            listTempsIds.Add(auxTemp[j, i]);
    //        }
    //    }
    //    temp = auxTemp;

    //}
    //private void makeMatrixRotateMove()
    //{
        
    //    //listTempsIds.Clear();
    //    //listActualIds.Clear();
    //    //int[,] auxTempMatrix = new int[temp.GetLength(0), temp.GetLength(1)];
    //    //int n = 0;
    //    //for (int i = 0; i < newHeight; i++)
    //    //{
    //    //    for (int j = newWidht - 1; j >= 0; j--)
    //    //    {
    //    //        listTempsIds.Add(temp[i, j]);
    //    //        //listActualIds.Add(temp[i,n]);
    //    //        auxTempMatrix[i, n] = temp[i, j];
    //    //        //Debug.Log(temp[i, n]);
    //    //        n++;

    //    //    }
    //    //    n = 0;
    //    //}

    //    //matrix = new int[temp.GetLength(0), temp.GetLength(1)];
    //    //matrix = auxTempMatrix;
    //}


    private void RotateMove() {

        Soldier actualSoldier = Soldier.listSoldiers[0];
        Soldier.listSoldiersTemp.Clear();
        //tempNewHeight = newHeight;
        //tempNewWidht = newWidht;
        EventActionsController.newWidht = EventActionsController.newHeight;
        EventActionsController.newHeight = EventActionsController.tempNewWidht;
        int n=0;
        int auxHeight = EventActionsController.newHeight;
        //int j = 1;
        int cont = 0;
        //Debug.Log("Entro");
        for (int j=1;j<= EventActionsController.newWidht;j++)
        {
            int tempJ = j;
            
            //Debug.Log(j);
            for (int i = auxHeight; i>(auxHeight- EventActionsController.newHeight); i--)
            {
                for (int z = 0; z < Soldier.listSoldiers.Count; z++)
                {
                    if (("soldier_" + (listActualIds[n]).ToString() == Soldier.listSoldiers[z].SoldierGO.name))
                    {
                        //Debug.Log(listActualIds[n]);
                        soldierActualGO = Soldier.listSoldiers[z].SoldierGO;
                        actualSoldier = Soldier.listSoldiers[z];
                        cont++;
                        break;
                    }
                }
            
                //Debug.Log((newWidht - j) + " " + (newHeight - i));
                if (soldierActualGO != null) { 
                    //soldierActualGO.GetComponent<Transform>().position = new Vector3(actualSoldier.PositionX + (EventActionsController.newWidht - j), actualSoldier.PositionY - (EventActionsController.newHeight - i), 0.99f);
                    Soldier.listSoldiersTemp.Add(new Soldier(actualSoldier.Life, actualSoldier.LifeDB, actualSoldier.TypeSoldier, actualSoldier.Strength, actualSoldier.TypeAttacks, actualSoldier.SpecialAbility,
                        actualSoldier.IconUnit, actualSoldier.PositionX + (EventActionsController.newWidht - j), actualSoldier.PositionY - (EventActionsController.newHeight - i), actualSoldier.Id, soldierActualGO, actualSoldier.Material));
                    //AddSoldierToListTemp(listTempsIds[i], Soldier.listSoldiers[i], soldierActual.GetComponent<Transform>().position,soldierActual);
                }
                else
                {
                    Debug.Log("No se encuentra el objeto de nombre soldier" + (listTempsIds[i]));
                }
                n++;
                if (cont!= EventActionsController.newHeight)
                {
                    j++;
                }
                else
                {
                    j = tempJ;
                    auxHeight++;
                    cont = 0;
                    break;
                }
            }
        }
        //Soldier.listSoldiers = new List<Soldier>(Soldier.listSoldiersTemp);
    }
    

   

    //void PrintMatrix(String text, int caseNumber)
    //{
    //    String cadena = null;
    //    Debug.Log(text);
    //    if (caseNumber == 1)
    //    {
    //        for (int i = 0; i < EventActionsController.newHeight; i++)
    //        {
    //            for (int j = 0; j < EventActionsController.newWidht; j++)
    //            {
    //                cadena = cadena + " " + matrix[i, j];
    //            }
    //            Debug.Log(cadena);
    //            cadena = null;
    //        }
    //    }
    //    else
    //    {
    //        for (int i = 0; i < temp.GetLength(0); i++)
    //        {
    //            for (int j = 0; j < temp.GetLength(1); j++)
    //            {
    //                cadena = cadena + " " + temp[i, j];
    //            }
    //            Debug.Log(cadena);
    //            cadena = null;
    //        }
    //    }
    //}
    

    //void ChangePositionSoldiersRotate()
    //{
    //    //for (int j = 0; j < Soldier.listSoldiers.Count; j++)
    //    //{
    //    //    if (Soldier.listSoldiers[j].Id!=0)
    //    //    {
    //    //        Debug.Log(Soldier.listSoldiers[j].SoldierGO.name + " " + Soldier.listSoldiers[j].PositionX + " " + Soldier.listSoldiers[j].PositionY);
    //    //    }
            
    //    //}
    //    if (FormationGO!=null)
    //    {
    //        FormationGO.transform.GetChild(0).transform.Rotate(0.0f, 0.0f, -90.0f, Space.Self);
    //        for (int j = 0; j < Soldier.listSoldiers.Count; j++)
    //        {
    //            Soldier.listSoldiers[j].SoldierGO.GetComponent<Transform>().Rotate(0.0f, 0.0f, 90.00f, Space.Self);
    //            Soldier.listSoldiers[j].PositionX = Mathf.RoundToInt(Soldier.listSoldiers[j].SoldierGO.GetComponent<Transform>().position.x);
    //            Soldier.listSoldiers[j].PositionY = Mathf.RoundToInt(Soldier.listSoldiers[j].SoldierGO.GetComponent<Transform>().position.y);
    //            //Debug.Log(Soldier.listSoldiers[j].SoldierGO.name + " " + Soldier.listSoldiers[j].PositionX + " " + Soldier.listSoldiers[j].PositionY);
    //        }
    //    }
    //    else
    //    {
    //        Debug.Log("No se ha asignado el objeto Formación en el script ControllerFormation");
    //    }
    //    int temp = newWidht;
    //    newWidht = newHeight;
    //    newHeight = temp;
    //    Debug.Log(newWidht + " " + newHeight);
    //}
    void CreateListTempSoldiers()
    {
        Soldier actualSoldier = Soldier.listSoldiers[0];
        Soldier.listSoldiersTemp.Clear();
        //for (int i = 0; i < listActualIds.Count; i++)
        //{
        //    Debug.Log(listActualIds[i]); ;
        //}

        //for (int i = 0; i < listActualIds.Count; i++)
        //{

        //    Debug.Log(listTempsIds[i]);
        //}
        for (int i = 0; i < listActualIds.Count; i++)
        {
            for (int j = 0; j < Soldier.listSoldiers.Count; j++)
            {
                // Debug.Log(listActualIds.Count+ " "+ listTempsIds.Count + " "+ listActualIds[i] + " "+listTempsIds[i]);
                if (("soldier_" + (listTempsIds[i]).ToString() == Soldier.listSoldiers[j].SoldierGO.name))
                {
                    soldierActualGO = Soldier.listSoldiers[j].SoldierGO;
                    actualSoldier = Soldier.listSoldiers[j];
                    break;
                }
            }
            if (soldierActualGO != null)
            { 
                //soldierActualGO.GetComponent<Transform>().position = new Vector3(Soldier.listSoldiers[i].PositionX, Soldier.listSoldiers[i].PositionY, 0.99f);
                Soldier.listSoldiersTemp.Add(new Soldier(actualSoldier.Life, actualSoldier.LifeDB, actualSoldier.TypeSoldier, actualSoldier.Strength, actualSoldier.TypeAttacks, actualSoldier.SpecialAbility,
                actualSoldier.IconUnit, Soldier.listSoldiers[i].PositionX, Soldier.listSoldiers[i].PositionY, actualSoldier.Id, soldierActualGO,actualSoldier.Material));
                
            }
            else
            {
                Debug.Log("No se encuentra el objeto de nombre soldier" + (listTempsIds[i]));
            }

        }
        //Debug.Log("Cont" + Soldier.listSoldiersTemp.Count);
        //Soldier.listSoldiers.Clear();
        //Soldier.listSoldiers = new List<Soldier>(Soldier.listSoldiersTemp);
        //Soldier.listSoldiersTemp.Clear();
        //createSoldierController.listIds.Clear();
        //createSoldierController.listIds = new List<int>(listActualIds); 
    }
    //void ChangePositionSoldiers(int caseNumber,List<int> listId,List<int> auxListId,List<Soldier> listSoldier)
    //{
    //    Soldier actualSoldier=listSoldier[0];
    //    Soldier.listSoldiersTemp.Clear();

    //    for (int i = 0; i < listId.Count; i++)
    //    {
    //        for (int j = 0; j < listSoldier.Count; j++)
    //        {
    //            // Debug.Log(listActualIds.Count+ " "+ listTempsIds.Count + " "+ listActualIds[i] + " "+listTempsIds[i]);
    //            if (("soldier_" + (auxListId[i]).ToString() == listSoldier[j].SoldierGO.name))
    //            {
    //                soldierActualGO = listSoldier[j].SoldierGO;
    //                actualSoldier = listSoldier[j];
    //                break;
    //            }
    //        }
    //        if (soldierActualGO != null)
    //        { //soldierActual.GetComponent<Transform>().position = createSoldierController.listPositions[i];
    //            soldierActualGO.GetComponent<Transform>().position = new Vector3(listSoldier[i].PositionX, listSoldier[i].PositionY, 0.99f);
    //            Soldier.listSoldiersTemp.Add(new Soldier(actualSoldier.Life, actualSoldier.LifeDB, actualSoldier.TypeSoldier, actualSoldier.Strength, actualSoldier.TypeAttacks, actualSoldier.SpecialAbility,
    //                actualSoldier.IconUnit, listSoldier[i].PositionX, listSoldier[i].PositionY, actualSoldier.Id, soldierActualGO,actualSoldier.Material));
    //            //AddSoldierToListTemp(listTempsIds[i], Soldier.listSoldiers[i], soldierActual.GetComponent<Transform>().position,soldierActual);
    //        }
    //        else
    //        {
    //            Debug.Log("No se encuentra el objeto de nombre soldier" + (listTempsIds[i]));
    //        }

    //    }
    //    //Debug.Log("Cont" + Soldier.listSoldiersTemp.Count);
    //    if (caseNumber==2){
    //        listSoldierRotate.Clear();
    //        listSoldierRotate = new List<Soldier>(Soldier.listSoldiersTemp);

    //    }
    //    else
    //    {
    //        Soldier.listSoldiers.Clear();
    //        Soldier.listSoldiers = new List<Soldier>(Soldier.listSoldiersTemp);
    //    }

    //    Soldier.listSoldiersTemp.Clear();
    //    //createSoldierController.listIds.Clear();
    //    //createSoldierController.listIds = new List<int>(listActualIds); 
    //}


    //private void ReadListSoldier(List<Soldier> listSoldier, List<int> listIds)
    //{
    //    //for (int i = 0; i < SelectedSoldiers.listSoldiers.Count; i++)
    //    //{
    //    //    Debug.Log("VALOR i:" + i + "Soldado posX" + SelectedSoldiers.listSoldiers[i].getPositionX() + "Soldado posY" + SelectedSoldiers.listSoldiers[i].getPositionY());
    //    //}
    //    listIds.Clear();

    //    SoldierCompare sc = new SoldierCompare();
    //    listSoldier.Sort(sc);

    //    for (int i = 0; i < listSoldier.Count; i++)
    //    {
    //        //Debug.Log("Soldado posX" + Soldier.listSoldiers[i].getPositionX() + "Soldado posY" + Soldier.listSoldiers[i].getPositionY());
    //        string[] str = listSoldier[i].SoldierGO.name.Split(char.Parse("_"));
    //        int soldierId = Int32.Parse(str[1]);
    //        listIds.Add(soldierId);
    //        //Debug.Log(Soldier.listSoldiers[i].SoldierGO.name);
    //    }
    //    //if (start)
    //    //{
    //    //    listSoldierRotate = new List<Soldier>(Soldier.listSoldiers);
    //    //    listActualIdsRotate = new List<int>(listActualIds);
    //    //    start = false;
    //    //}
    //}


    //void ChangePositionSoldiers()
    //{
    //    Soldier actualSoldier = Soldier.listSoldiers[0];
    //    Soldier.listSoldiersTemp.Clear();

    //    for (int i = 0; i < listActualIds.Count; i++)
    //    {
    //        for (int j=0;j< Soldier.listSoldiers.Count;j++)
    //        {
    //           // Debug.Log(listActualIds.Count+ " "+ listTempsIds.Count + " "+ listActualIds[i] + " "+listTempsIds[i]);
    //            if (("soldier_" + (listTempsIds[i]).ToString()== Soldier.listSoldiers[j].SoldierGO.name)){
    //                soldierActualGO = Soldier.listSoldiers[j].SoldierGO;
    //                actualSoldier = Soldier.listSoldiers[j];
    //                break;
    //            }
    //        }
    //        if (soldierActualGO != null)
    //        { //soldierActual.GetComponent<Transform>().position = createSoldierController.listPositions[i];
    //            soldierActualGO.GetComponent<Transform>().position = new Vector3(Soldier.listSoldiers[i].PositionX, Soldier.listSoldiers[i].PositionY, 0.99f);
    //            Soldier.listSoldiersTemp.Add(new Soldier(actualSoldier.Life, actualSoldier.LifeDB, actualSoldier.TypeSoldier, actualSoldier.Strength, actualSoldier.TypeAttacks, actualSoldier.SpecialAbility,
    //                actualSoldier.IconUnit, Soldier.listSoldiers[i].PositionX, Soldier.listSoldiers[i].PositionY, actualSoldier.Id, soldierActualGO));
    //            //AddSoldierToListTemp(listTempsIds[i], Soldier.listSoldiers[i], soldierActual.GetComponent<Transform>().position,soldierActual);
    //        }
    //        else
    //        {
    //            Debug.Log("No se encuentra el objeto de nombre soldier"+ (listTempsIds[i]));
    //        }

    //    }
    //    Debug.Log("Cont"+ Soldier.listSoldiersTemp.Count);
    //    Soldier.listSoldiers.Clear();
    //    Soldier.listSoldiers = new List<Soldier>(Soldier.listSoldiersTemp);
    //    Soldier.listSoldiersTemp.Clear();
    //    //createSoldierController.listIds.Clear();
    //    //createSoldierController.listIds = new List<int>(listActualIds); 
    //}

    //private void AddSoldierToListTemp(int soldierId, Vector3 position)
    //{
    //    for (int i = 0; i < Soldier.listSoldiers.Count; i++)
    //    {
    //        if (soldierId == Soldier.listSoldiers[i].Id)
    //        {
    //            Soldier.listSoldiersTemp.Add(new Soldier(Soldier.listSoldiers[i].Life, Soldier.listSoldiers[i].LifeDB, Soldier.listSoldiers[i].TypeSoldier, Soldier.listSoldiers[i].Strength, Soldier.listSoldiers[i].TypeAttacks, Soldier.listSoldiers[i].SpecialAbility,
    //                Soldier.listSoldiers[i].IconUnit, position.x, position.y, soldierId, Soldier.listSoldiers[i].SoldierGO, Soldier.listSoldiers[i].Material));
    //            break;
    //        }
    //    }
    //}

    //void GenerateMatrix(int Widht, int Height, int caseNumber)
    //{
    //    int n = 0;

    //    matrix = new int[Height, Widht];
    //    temp = new int[Height, Widht];

    //    //Debug.Log(listActualIds.Count);
    //    for (int i = 0; i < Height; i++)
    //    {
    //        for (int j = 0; j < Widht; j++)
    //        {
    //            if (caseNumber==2)
    //            {
    //                matrix[i, j] = listActualIdsRotate[n];
    //                temp[i, j] = listActualIdsRotate[n];
    //            }
    //            else
    //            {
    //                matrix[i, j] = listActualIds[n];
    //                temp[i, j] = listActualIds[n];
    //            }

    //            n++;
    //        }
    //    }
    //}
    //void VerticalMove()
    //{
    //    listTempsIds.Clear();
    //    int x = 0;

    //    //La última fila pasa a ser la primera en matrix

    //    for (int j = 0; j < newWidht; j++)
    //    {
    //        matrix[x, j] = temp[newHeight - 1, j];
    //        listTempsIds.Add(matrix[x, j]);
    //    }
    //    x++;
    //    for (int i = 0; i < newHeight-1; i++)
    //    {
    //        for (int j = 0; j < newWidht; j++)
    //        {
    //            matrix[x, j] = temp[i, j];
    //            listTempsIds.Add(matrix[x, j]);
    //        }
    //        x++;
    //    }
    //}
    //void VerticalMove(int Widht, int Height, int caseNumber)//1-->newDimension formation 2-->Dimension.formation SO
    //{
    //    if (caseNumber == 2)
    //    {
    //        listTempsIdsRotate.Clear();
    //    }
    //    else
    //    {
    //        listTempsIds.Clear();
    //    }
    //    int x = 0;

    //    //La última fila pasa a ser la primera en matrix

    //    for (int j = 0; j < Widht; j++)
    //    {
    //        matrix[x, j] = temp[Height - 1, j];
    //        if (caseNumber == 2)
    //        {
    //            listTempsIdsRotate.Add(matrix[x, j]);
    //        }
    //        else
    //        {
    //            listTempsIds.Add(matrix[x, j]);
    //        }

    //    }
    //    x++;
    //    for (int i = 0; i < Height - 1; i++)
    //    {
    //        for (int j = 0; j < Widht; j++)
    //        {
    //            matrix[x, j] = temp[i, j];
    //            if (caseNumber == 2)
    //            {
    //                listTempsIdsRotate.Add(matrix[x, j]);
    //            }
    //            else
    //            {
    //                listTempsIds.Add(matrix[x, j]);
    //            }
    //        }
    //        x++;
    //    }
    //}

    //private void HorizontalMove(int Widht, int Height, int caseNumber)//1-->newDimension formation 2-->Dimension.formation SO
    //{
    //    float[] firstColumn = new float[Height];

    //    for (int i = 0; i < Height; i++)
    //    {
    //        for (int j = 1; j < Widht; j++)
    //        {
    //            matrix[i, j - 1] = temp[i, j];
    //        }
    //    }

    //    //Coloca la primera columna por la izquierda al final
    //    for (int i = 0; i < Height; i++)
    //    {
    //        matrix[i, (Widht - 1)] = temp[i, 0];
    //        firstColumn[i] = matrix[i, (Widht - 1)];
    //    }
    //    UpdateListActualIds(caseNumber);

    //}
    //private void UpdateListActualIds(int caseNumber)
    //{
    //    if (caseNumber == 2)
    //    {
    //        listTempsIdsRotate.Clear();
    //    }
    //    else
    //    {
    //        listTempsIds.Clear();
    //    }

    //    for (int i = 0; i < matrix.GetLength(0); i++)
    //    {
    //        for (int j = 0; j < matrix.GetLength(1); j++)
    //        {
    //            if (caseNumber == 2)
    //            {
    //                listTempsIdsRotate.Add(matrix[i, j]);
    //            }
    //            else
    //            {
    //                listTempsIds.Add(matrix[i, j]);
    //            }

    //        }
    //    }
    //}

    //void PrintMatrix(String text, int Widht, int Height)
    //{
    //    String cadena = null;
    //    Debug.Log(text);
    //    for (int i = 0; i < Height; i++)
    //    {
    //        for (int j = 0; j < Widht; j++)
    //        {
    //            cadena = cadena + " " + matrix[i, j];
    //        }
    //        Debug.Log(cadena);
    //        cadena = null;
    //    }
    //}

    //private void RotateMove(int Widht, int Height, int caseNumber)
    //{
    //    int colums = matrix.GetLength(1)-1;

    //    for (int i = 0; i < matrix.GetLength(0); i++)
    //    {
    //        for (int j = 0; j < matrix.GetLength(1); j++)
    //        {
    //            matrix[j, i] = temp[j, colums];
    //        }
    //        colums--;
    //    }
    //    UpdateListActualIds(caseNumber);
    //}

    //private void MatrixTranspose()
    //{
    //    int [,] auxTemp = new int[matrix.GetLength(1), matrix.GetLength(0)];

    //    Debug.Log(matrix.GetLength(0)+" "+matrix.GetLength(1)+" aux:"+auxTemp.GetLength(0)+" "+auxTemp.GetLength(1));
    //    for (int i = 0; i < auxTemp.GetLength(0); i++)
    //    {
    //        for (int j = 0; j < auxTemp.GetLength(1); j++)
    //        {
    //            matrix[i, j] = temp[j, i];
    //            auxTemp[i, j] = matrix[i, j];
    //        }
    //    }
    //    temp = auxTemp;

    //}
}


