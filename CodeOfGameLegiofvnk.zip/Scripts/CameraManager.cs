﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour
{
    private Transform followPlayer;
    private GameObject FormationGO;
    public Vector3 distanceCamera;

    public float speedCamera = 2f;

    public Camera myCamera;
    private Transform cameraTransform;

    void Start()
    {
        FormationGO = GameObject.Find("Formation");
        followPlayer = FormationGO.GetComponent<Transform>();
        cameraTransform = myCamera.transform;
    }

    void LateUpdate()
    {


        if (followPlayer != null)
        {
            cameraTransform.position = Vector3.Lerp(cameraTransform.position, followPlayer.position + distanceCamera, speedCamera * Time.deltaTime);
            //cameraTransform.LookAt(followPlayer.position);
        }
        else
        {
            Debug.Log("Gameobject Player no asignado");
        }

    }
}
