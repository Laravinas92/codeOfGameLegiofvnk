﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagerBeat : MonoBehaviour
{
    public int ppm;
    public static float pulse;
    public GameObject signal;
    public static float timePulse;
    public float previousOffset;
    public float nextOffset;

    public static float lowerLimitPulse;
    public static float upperLimitPulse;
    public static bool impar;
    private int contPulse;

    //public delegate void EventActionsController(string letter, Vector2 direction, string typeSoldier);
    //public static event EventActionsController eventActionsController;

    //private float time = 0.0f;

    void Start()
    {
        if (signal != null)
        {
            signal.SetActive(false);
            lowerLimitPulse = previousOffset;
            upperLimitPulse = nextOffset;
            signal.GetComponent<MeshRenderer>().material.color = Color.green;
            pulse = 60 / ppm;
            InvokeRepeating("ActiveSignal", 2.0f, pulse);
        }
        else
        {
            Debug.Log("Señal luminosa vacía");
        }
        
    }

    void ActiveSignal()
    {
        timePulse =Time.time;
        if (contPulse%2!=0)
        {
            Invoke("CallEventActions",upperLimitPulse);
            
        }
        signal.SetActive(true);
        contPulse++;
        //timer = true;
        //signal.GetComponent<MeshRenderer>().material.color = Color.green;
        Invoke("Wait",0.05f);

    }

    void Wait()
    {
        //signal.GetComponent<MeshRenderer>().material.color = Color.white;
        signal.SetActive(false);
    }
    void CallEventActions()
    {
        impar = true;

    }

}
