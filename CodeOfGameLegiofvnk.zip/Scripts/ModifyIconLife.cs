﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ModifyIconLife : MonoBehaviour
{
    public GameObject prefabHeartIzq;
    public GameObject prefabHeartDrch;
    public void PutSpriteLife(float life, GameObject gameObject)
    {

        Vector3 positionStartIcon = new Vector3(gameObject.transform.position.x - 0.35f, gameObject.transform.position.y + 0.35f, 0.9f);
        float positionPlus = 0;
        for (int j = 0; j < life; j++)
        {

            if (prefabHeartIzq != null && prefabHeartDrch != null)
            {
                if (j % 2 == 0)
                {
                    GameObject heartIzq = Instantiate(prefabHeartIzq, new Vector3(positionStartIcon.x + positionPlus, positionStartIcon.y, positionStartIcon.z), Quaternion.identity);
                    heartIzq.name = "Heart" + j;
                    heartIzq.transform.SetParent(gameObject.transform);
                }
                else
                {
                    GameObject hearDrch = Instantiate(prefabHeartDrch, new Vector3(positionStartIcon.x + positionPlus, positionStartIcon.y, positionStartIcon.z), Quaternion.identity);
                    hearDrch.name = "Heart" + j;
                    hearDrch.transform.SetParent(gameObject.transform);
                }

            }
            else
            {

                Debug.Log("No se ha asignado Objeto prefabHeartIzq ó prefabHeartDrch en el inspector,script FindEnemies ");
                break;
            }
            positionPlus = positionPlus + 0.12f;
        }
    }


    public void ActiveIconLife(float life, GameObject gameObject)
    {
        int n = 0;
        for (float i=0;i<life;i++)
        {
            if (!gameObject.transform.GetChild(n).transform.gameObject.activeInHierarchy)
            {
                gameObject.transform.GetChild(n).transform.gameObject.SetActive(true);
            }
            n++;
        }
    }
    public void DesactiveIconLife(float life, GameObject gameObject)
    {
        //int n = gameObject.transform.childCount-1
        //Debug.Log(life);
        for (int i = gameObject.transform.childCount-1; i >= life; i--)
        {
            //Debug.Log(gameObject.transform.GetChild(i).transform.gameObject.name +" "+life+" "+ i);
            if (gameObject.transform.GetChild(i).transform.gameObject.activeInHierarchy)
            {
                gameObject.transform.GetChild(i).transform.gameObject.SetActive(false);
            }
            //n--;
        }
    }
}
