﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif
//[CanEditMultipleObjects]
[ExecuteInEditMode]
public class SO_Manager : MonoBehaviour
{
    public dataBaseSoldiers LegionarioDB;
    public dataBaseSoldiers LegionarioMejoradoDB;
    public dataBaseSoldiers ArqueroDB;
    public dataBaseSoldiers CazadorDB;
    public dataBaseSoldiers HonderoDB;
    public dataBaseSoldiers LanceroDB;
    public dataBaseSoldiers GladiadorDB;
    public dataBaseSoldiers PretorianoDB;
    public dataBaseSoldiers MedicoDB;
    public dataBaseSoldiers SacerdoteDB;
    public dataBaseSoldiers BarbaroDB;
    public DataBaseItems itemsDB;
    public dataBaseScenary scenaryDB;
    public dataBaseSoldiers UpdateMaterialSoldier(GameObject soldier,string type, int numberCase)//1 change material, 2 return database
    {
        dataBaseSoldiers soldierDBSelected;
        
        switch (type)
        {
            case "Legionario":
                soldierDBSelected = LegionarioDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType= SelecTypeEnemy.typeEnemy.Legionario;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "LegionarioMejorado":
                
                soldierDBSelected = LegionarioMejoradoDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.LegionarioMejorado;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "Arquero":
                soldierDBSelected = ArqueroDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Arquero;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "Cazador":
                soldierDBSelected = CazadorDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Cazador;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "Hondero":
                soldierDBSelected = HonderoDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Hondero;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "Lancero":
                soldierDBSelected = LanceroDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Lancero;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "Gladiador":
                soldierDBSelected = GladiadorDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Gladiador;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "Pretoriano":
                soldierDBSelected = PretorianoDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Pretoriano;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "Medico":
                soldierDBSelected = MedicoDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Medico;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "Sacerdote":
                soldierDBSelected = SacerdoteDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Sacerdote;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            case "Barbaro":
                soldierDBSelected = BarbaroDB;
                if (numberCase == 1)
                {
                    soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Barbaro;
                    soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                }
                break;
            default:
                //soldierDBSelected = (dataBaseSoldiers)AssetDatabase.LoadAssetAtPath("Assets/SO/Soldados/Legionario.asset", typeof(dataBaseSoldiers));
                soldierDBSelected = LegionarioDB;
                soldier.GetComponent<SelecTypeEnemy>().EnemyType = SelecTypeEnemy.typeEnemy.Legionario;
                soldier.GetComponent<MeshRenderer>().sharedMaterial = soldierDBSelected.materialEnemy;
                break;
        }
        return soldierDBSelected;
    }

    public string UpdateMaterialPiece(GameObject piece,string pieceName)
    {
        switch (pieceName)
        {
            case "Llanura_1":
                
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Llanura_1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialLlanura_1;
                break;
            case "Llanura_2":

                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Llanura_2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialLlanura_2;
                break;

            case "LlanuraElevacion":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.LlanuraElevacion;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialLlanuraElevacion;
                break;

            case "Pared":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Pared;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialPared;
                break;

            case "Arbol_Llanura_1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Arbol_Llanura_1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialArbol_Llanura_1;
                break;
            case "Arbol_Llanura_2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Arbol_Llanura_2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialArbol_Llanura_2;
                break;

            case "Agua":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Agua;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAgua;
                break;

            case "Camino":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Camino;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialCamino;
                break;

            case "Camino1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Camino1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialCamino1;
                break;

            case "Camino2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Camino2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialCamino2;
                break;

            case "Camino3":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Camino3;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialCamino3;
                break;

            case "Camino4":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Camino4;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialCamino4;
                break;

            case "Camino5":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Camino5;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialCamino5;
                break;

            case "Camino6":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Camino6;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialCamino6;
                break;

            case "Camino7":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Camino7;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialCamino7;
                break;

            case "Camino8":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Camino8;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialCamino8;
                break;

            case "PuentePiedraL":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.PuentePiedraL;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialPuentePiedraL;
                break;
            case "PuentePiedraR":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.PuentePiedraR;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialPuentePiedraR;
                break;

            case "PuenteMadera":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.PuenteMadera;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialPuenteMadera;
                break;

            case "Columna_Llanura_1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Columna_Llanura_1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialColumna_Llanura_1;
                break;
            case "Columna_Llanura_2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Columna_Llanura_2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialColumna_Llanura_2;
                break;

            case "Empalizada_Llanura_1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Empalizada_Llanura_1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialEmpalizada_Llanura_1;
                break;
            case "Empalizada_Llanura_2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Empalizada_Llanura_2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialEmpalizada_Llanura_2;
                break;

            case "Barril_Llanura_1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Barril_Llanura_1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialBarril_Llanura_1;
                break;
            case "Barril_Llanura_2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Barril_Llanura_2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialBarril_Llanura_2;
                break;

            case "Tienda":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Tienda;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialTienda;
                break;

            case "Hoguera":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Hoguera;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialHoguera;
                break;

            case "Planta1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Planta1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialPlanta1;
                break;

            case "Planta2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Planta2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialPlanta2;
                break;

            case "Flores":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Flores;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialFlores;
                break;

            case "Tocon":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Tocon;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialTocon;
                break;

            case "Tocon2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Tocon2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialTocon2;
                break;

            case "AcantiladoDM":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoDM;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoDM;
                break;

            case "AcantiladoDL":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoDL;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoDL;
                break;

            case "AcantiladoDR":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoDR;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoDR;
                break;
            case "AcantiladoL1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoL1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoL1;
                break;
            case "AcantiladoL2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoL2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoL2;
                break;
            case "AcantiladoR1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoR1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoR1;
                break;
            case "AcantiladoR2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoR2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoR2;
                break;

            case "AcantiladoUM1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoUM1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoUM1;
                break;
            case "AcantiladoUM2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoUM2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoUM2;
                break;

            case "AcantiladoUL1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoUL1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoUL1;
                break;
            case "AcantiladoUL2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoUL2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoUL2;
                break;

            case "AcantiladoUR1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoUR1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoUR1;
                break;
            case "AcantiladoUR2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoUR2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoUR2;
                break;
            case "AcantiladoR2X":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoR2X;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoR2X;
                break;
            case "AcantiladoR1X":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoR1X;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoR1X;
                break;
            case "AcantiladoL2X":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoL2X;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoL2X;
                break;
            case "AcantiladoL1X":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.AcantiladoL1X;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialAcantiladoL1X;
                break;
            case "Pan":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Pan;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialPan;
                break;

            case "Manzana":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Manzana;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialManzana;
                break;

            case "Pollo":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Pollo;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialPollo;
                break;

            case "Queso":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Queso;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialQueso;
                break;

            case "HierbaCurativa":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.HierbaCurativa;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialHierbaCurativa;
                break;

            case "Dinero1_Llanura1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Dinero1_Llanura1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialDinero1_Llanura1;
                break;
            case "Dinero2_Llanura1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Dinero2_Llanura1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialDinero2_Llanura1;
                break;
            case "Dinero3_Llanura1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Dinero3_Llanura1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialDinero3_Llanura1;
                break;
            case "Dinero1_Llanura2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Dinero1_Llanura2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialDinero1_Llanura2;
                break;
            case "Dinero2_Llanura2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Dinero2_Llanura2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialDinero2_Llanura2;
                break;
            case "Dinero3_Llanura2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Dinero3_Llanura2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialDinero3_Llanura2;
                break;
            case "Dinero1":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Dinero1;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialDinero1;
                break;
            case "Dinero2":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Dinero2;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialDinero2;
                break;
            case "Dinero3":
                piece.GetComponent<SelectMaterial>().piece = SelectMaterial.typePiece.Dinero3;
                pieceName = piece.ToString();
                piece.GetComponent<MeshRenderer>().sharedMaterial = scenaryDB.materialDinero3;
                break;
            default:
                Debug.Log("No existe Item");
                break;

        }
        return pieceName;
    }
    public void AddItemToList(GameObject item, bool giveReward)
    {
        
        for (int j = 0; j < itemsDB.item.Length; j++)
        {
            string nameItem = item.GetComponent<SelectMaterial>().piece.ToString();

            if (nameItem== "Dinero1_Llanura1" || nameItem == "Dinero1_Llanura2" || nameItem == "Dinero1")
            {
                nameItem = "Dinero1";
            }
            else
            {
                if (nameItem == "Dinero2_Llanura1" || nameItem == "Dinero2_Llanura2" || nameItem == "Dinero2")
                {
                    nameItem = "Dinero2";
                }
                else
                {
                    if (nameItem == "Dinero3_Llanura1" || nameItem == "Dinero3_Llanura2" || nameItem == "Dinero3")
                    {
                        nameItem = "Dinero3";
                    }
                }
            }

            if (nameItem == itemsDB.item[j].nameObject)
            {
                FindObjects.listReward.Add(new Items(itemsDB.item[j].nameObject, itemsDB.item[j].affectation, giveReward, item));
                break;
            }
        }
    }
}

